<html>
    <title>About Us</title>


        <head>
                <title>About Us</title>
                <!-- <img src="ourLibrary.png"/> -->
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta charset="utf-8">

            <?php include 'header.php'; ?>

                <style>
                    body{
                        background-color: #EAFFFB;
                    }
                    .container{
                        margin: auto;
                        width: 50%;
                        border: ridge 5px  grey;
                        padding: 10px;
                        font-size:25px;
                        text-align:justify;
                        background-color:grey;
                        background:	rgb(192,192,192, 0.8);
                    }
                
                  

                  

            </style>
                
                </head>      
                 <body>
                    
                <!-- Start About Us Section -->
                <section id="about-section" class="about-section">
                <div class="container">
                  
                   
                  
                    <div class="col-md-7">
                        <div class="about-text">
                        <p><h4><br>Our Library is a library established for young people by young people.We make it easier to find the genres that you may be most interested in and make it easy by offering a strictly online library. With our ebooks, you can read on the go, on your phone, tablet,pc or mac. Just click and read!</h4></p>
                        <p><h4>We are commited to providing our members with the best and widest variety of books.</h4></p>
                        </div>
                        
                        <div class="about-list">
                            <h4>Some important Feature</h4>
                            <ul>
                                <li><i class="fa fa-check-square"></i>We aim to have the best variety of books.</li>
                                <li><i class="fa fa-check-square"></i>And strive to give a smooth user experience!</li>
                                <li><i class="fa fa-check-square"></i>Come on and rekindle your love of reading!</li>

                                <p> Our Library serves as an educational and recreational resource for all residents of the town. We provide materials and services to help community residents obtain information to meet their educational, professional, and personal needs. Special emphasis is placed on supporting students at all academic levels and on stimulating young children’s interest in and appreciation for reading and learning. </p>
                                
                            </ul>
                            
                            
                        </div>
                        
                    </div>
                        
                        
                        
                    </div>
                </div>
              
            </section>

            </div>  

                </br></br>
                
                <!-- Start About-section 2 -->
                <section id="about-section-2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                        <div class="about-text">
                          
                            <h2>Vision Statement </h2>
                            <p>Our Library is committed to maintaining a strong professional staff, a high-quality collection of materials, and an attractive, functional building. It is a center for lifelong learning and a community meeting place where the Trustees, staff, and volunteers work to maintain a refuge for contemplation, intellectual stimulation, and friendly discourse. The Library welcomes all and strives to satisfy the needs of patrons of diverse ages, backgrounds, and abilities.
</p>
                        </div>
                            
                        
                    </div>
                       
                
            </br></br></br></br>
                </div>
                </div>
            <?php include 'footer.php'; ?>
        </body>

   
</html>