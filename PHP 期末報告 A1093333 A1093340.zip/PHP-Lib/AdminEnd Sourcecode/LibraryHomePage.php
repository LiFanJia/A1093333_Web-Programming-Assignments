<!DOCTYPE html>
<html>
<head>
    <title>Homepage</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">


    <?php include 'header.php'; ?>

         <style>
           body{
                background-color: turquoise;
            }

            #my{
            zoom: 100%;
            }
 
  
            body {
                
                background-color: #DBF9FC;
            }

           
            
            .img{  

                text-align:center;
                border:none;
                height: 50%;
                width: 100%;
                object-fit: contain;
                position: center;
                }
                .container {
                width: 100%;
                height: auto;
                margin: right 0;;
                margin:left:0;
                position:center;
                
                }

                .cat {
                height:100%;
                width: 100%;
            }

        </style>

</head>
<body>


        </br></br>

    <div class="img div">        

        <p class="center">

        </br>  <img src ='http://localhost/PHPLibraryProject/heroImage.jpeg' alt="heroImage" width="1100" height="400" alt="centered image">
        </p>       
    </div> 

</body>


   
      


         
<?php include 'footer.php'; ?>

</html>
