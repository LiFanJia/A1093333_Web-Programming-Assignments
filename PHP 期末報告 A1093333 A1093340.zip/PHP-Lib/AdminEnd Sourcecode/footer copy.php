<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content=
        "width=device-width, initial-scale=1" />
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  
<style>
.footer {
   position: relative;
   left: 0;
   top:70;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: white;
   text-align: center;

   
        .fa:hover {
            opacity: 0.9;
        }
  
        .fa-facebook {
            background: #007bb5;
            color: white;
        }
  
        .fa-twitter {
            background: #cb2027;
            color: white;
        }
  
        .fa-instagram {
            background: #ff5700;
            color: white;
        }
  
        .fa {
            padding: 20px;
            font-size: 40px;
            width: 60px;
            text-decoration: none;
            margin: 5px 80px;
        }
  
      
}
</style>
</head>
<body>



<div class="footer">
  <p><center>
        <h3>Connect With Us</h3>
        <h2>Send Us An Email</h2>
        <p><a href = "mailto: ourlibrary8888@mail.thisschool.com">Send Email</a></p>

  
        <!-- Add fonts icons -->
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-instagram"></a>

    </center>
</p>
</div>

</body>
</html> 
