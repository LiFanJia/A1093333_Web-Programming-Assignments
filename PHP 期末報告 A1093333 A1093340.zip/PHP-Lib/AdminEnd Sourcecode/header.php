<!doctype html>
<html>
    <head>
   
    <title>header.php</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
         .header {
        overflow: hidden;
        padding: 20px 10px;
    }

    .header a {
        margin : 0 10px;
        background-color: #BDEDFF;
        float: left;
        color: black;
        text-align: center;
        padding: 12px;
        text-decoration: none;
        font-size: 15px;
        line-height: 0px;
        border-radius: 4px;
        margin-bottom:15px;
    }

    .header a.logoimg {
        margin : -10px 20px;
    }

    .header a.logotxt {
        margin : 8px -20px;
        font-size : 25px;
        font-weight : bold;
    }

    .header a:hover {
        background-color: #96DED1
        /* #ddd; */
        color: black;
    }

    .header a.active {
        background-color: #2691d9;
        color: white;
    }

    .header-right {
        float: right;
    }
   
        </style>   
<


    </head>      
    
<body>


        <div class = "header">
    <a class = "logoimg"> <img src = "Images\ourLibrary.png" width = 50px height = 50px></a></br></br></br>
    <p><a class = "logotxt">OurLibrary</a></p>
    <div class = "header-right">
        <a class = "active" href = "admin/login.php"> Login</a>
        <a href = "admin/register.php">Register</a>
        <a href = "aboutus.php">About Us</a>
        <a href = "latestNews.php">Lastest News</a>
        <a href = "events.php">Events</a>
        <a href="admin/login.php">Admin</a>
    </div>
</div>
  <!-- <div class="searchbar">
        </br><form form id="form" role="search" style="float:left;display:inline-block;line-height:40px;padding-right:10px;">
				<input type="search" id="query" name="searchbar" placeholder="search.." size="80" 
                aria-label="Search through the site content">
                <button>Search</button>
			</form>
    </div>    -->
<!-- <!-- <div class="searchbar"> -->
<script async src="https://cse.google.com/cse.js?cx=9171d23ea1ea2d967"></script>
<div class="gcse-search"></div>
</div>  
 
        </br></br>
    </body>    
</html>