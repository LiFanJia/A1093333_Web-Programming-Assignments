<?php

if (!isset($_SESSION['stuID']) && $_SESSSION['stuRole'] != 'Administrator'){
    echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    exit();
}

@$stuID = $_GET['id'];
    if($stuID==''){
      
      redirect("index.php");
    }

$user = New User();
$singleuser = $user->single_user($stuID);
  
?>

<html>
<head>

<title>Update User - OurLibrary</title>

<style>

    body {
        position: relative;
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : #EAFFFB;
        height : 100vh;
    }

    
    .center {
        width : 750px;
        background : #fff;
        border-radius : 10px;
        text-align: center;
        position: center;
        margin: auto;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .header {
        overflow: hidden;
        padding: 20px 10px;
    }

    .header a {
        margin : 0 10px;
        background-color: #ffffff;
        float: left;
        color: black;
        text-align: center;
        padding: 12px;
        text-decoration: none;
        font-size: 15px;
        line-height: 0px;
        border-radius: 4px;
    }

    .header a.logoimg {
        margin : -10px 20px;
    }

    .header a.logotxt {
        margin : 8px -20px;
        font-size : 25px;
        font-weight : bold;
    }

    .header a:hover {
        background-color: #ddd;
        color: black;
    }

    .header a.active {
        background-color: #2691d9;
        color: white;
    }

    .header-right {
        float: right;
    }

    @media screen and (max-width: 500px) {
        .header a {
            float: none;
            display: block;
            text-align: left;
        }
        .header-right {
            float: none;
        }
    }
    
    .hero {
    position: relative;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    }

    .hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url(/img/Digital-Library-2048x1494.jpeg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    filter: brightness(60%);
    }

    .hero-content {
    position: relative;
    font-family: "Monserrat", sans-serif;
    color: white;
    text-align: center;
    margin: 0.625rem;
    }

    .hero-title {
    font-size: 3rem;
    font-weight: 600;
    margin-bottom: 0;
    }

    .hero-subtitle {
    font-size: 2rem;
    font-weight: 200;
    margin-top: 1rem;
    }

    .hero-button {
    background-color: #ae2d59;
    color: white;
    border: 1px solid #cb376a;
    margin-top: 5rem;
    padding: 0.9375rem1.875rem;
    font-family: "Monserrat", sans-serif;
    font-size: 1.125rem;
    font-weight: 200;
    cursor: pointer;
    }

    .hero-button:hover {
    background-color: #cb376a;
    border: 1px solid #db7598;
    }

    table, th, td{
        text-align: left;
    }

    th {
        height: 70px;
    }

    td {
        height: 80px;
        /* border:black; border-width:3px; border-style: solid; */
    }

    .titlebook {        
        border:black; 
        border-width:2px; 
        border-style: solid;
    }

    hr{
        width: 100%;
        background-color: black;
        border-color: black;  
    }

    .box{
        margin:20px;
        background-color: white;
    }

</style>

</head>

<body>

<div class = "box">
    <h2><b>&nbspUpdate User</b></h2>
</div>

<br/>

<div class = "box">

    <?php
        global $mydb;
    	$mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$stuID'");
                
        $cur = $mydb->executeQuery();
        if($cur==false){
            die(mysql_error());
        }
		$row_count = $mydb->num_rows($cur);//get the number of count
                    
        if ($row_count==1){
            echo "<table>";
            while ($row=mysqli_fetch_assoc($cur)){
                echo "<TR><TD>StudentID</TD>"; 
                echo "<TD> : ".$row["stuID"]."</TD></TD></TR>";
                echo "<TR><TD>First Name</TD>"; 
                echo "<TD> : ".$row["stuName"]."</TD></TD></TR>";
                echo "<TR><TD>Date of Birth</TD>"; 
                echo "<TD> : ".$row["stuBirth"]."</TD></TD></TR>";
                echo "<TR><TD>Email Address</TD>"; 
                echo "<TD> : ".$row["stuMail"]."</TD></TD></TR>";
                echo "<TR><TD>Phone</TD>"; 
                echo "<TD> : ".$row["stuPhone"]."</TD></TD></TR>";
                echo "<TR><TD>Role</TD>"; 
                echo "<TD> : ".$row["stuRole"]."</TD></TD></TR>";
                // echo "<TD>".$row["stuName"]."</TD><TD>".$row["stuID"]."</TD><TD>".$row["stuMail"]."</TD><TD>".$row["stuPhone"]."</TD><TD>".$row["stuBirth"]."</TD><TD><a href = 'deleteUser.php?stuNo=".$row["stuNo"]."'>Delete</a></TD><TD><a href = 'updateUser.php?stuNo=".$row["stuNo"]."'>Edit</a></TD><br/>";
            }
        
            echo "</table>";
echo "</div>";
            echo "<br/>";
        
            echo "<div class = 'box'>";
            echo "<table style = 'font-size : 18; font-family : Helvetica'>";
            echo "<form action = '' method = 'POST' enctype = 'multipart/form-data'>";
            echo "<input type='hidden' id='stuid' name='stuid' value='$stuID'>";
    	    $mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$stuID'");
            $cur = $mydb->executeQuery();
            if($cur==false){
                die(mysql_error());
            }

            while ($row=mysqli_fetch_assoc($cur)){
                echo "<TR><TH><u>Student ID:</u></TH>";
                echo "<TD>".$row["stuID"]."</TD></TR>";
                echo "<TR><TH><u>Name:</u></TH>";
                echo "<input type='hidden' id='stuname' name='stuname' value='$row[stuName]'>";
                echo "<TD>".$row["stuName"]."</TD></TR>"; 
                echo "<TR><TH><u>Date of Birth:</TD></TH>"; 
                echo "<TD>".$row["stuBirth"]."</TD></TR>";
                echo "<TR><TH><u>Email Address:</u></TD></TH>"; 
                echo "<TD><input type = 'email' style = width : 100%;  height :60% name = stuemail placeholder = 'Email Address' required></TD></TR>";
                echo "<TR><TH><u>Phone:<u></TD></TH>"; 
                echo "<TD><input type='tel' style = width : 100%; height : 60% pattern='[0-9]{10-12}' placeholder='Phone Number' name = stutel required></TD></TR>";
                echo "<TR><TH><u>Role:</u></TD></TH>"; 
                echo "<TD><input type = 'text' style = width : 100%;  height :60% name = sturole placeholder = 'Role' required></TD></TR>";
                echo "<TR><TH><u>Current Password:<u></TD></TH>"; 
                echo "<TD><input type='password' style = width : 100%; height : 60% placeholder='Current Password' name = oldpwd required></TD></TR>";
                echo "<TR><TH><u>New Password:<u></TD></TH>"; 
                echo "<TD><input type='password' style = width : 100%; height : 60% placeholder='New Password' name = stupwd required></TD></TR>";
                // echo "<TD>".$row["stuName"]."</TD><TD>".$row["stuID"]."</TD><TD>".$row["stuMail"]."</TD><TD>".$row["stuPhone"]."</TD><TD>".$row["stuBirth"]."</TD><TD><a href = 'deleteUser.php?stuNo=".$row["stuNo"]."'>Delete</a></TD><TD><a href = 'updateUser.php?stuNo=".$row["stuNo"]."'>Edit</a></TD><br/>";
            }
       
                echo "<TR><TD colspan='2'><button class='btn btn-primary' id='usersave' name='save' type='submit' ><i class='fa fa-save'></i> Save</button>";
                echo "<a href='index.php' class='btn btn-info'><span style='height:40px; width:80px;' class='fa fa-arrow-left'></span> List of Users</a></TD></TR>";

                echo "</form>";
            echo "</table>";

                echo "</div>";
                
                
        }else{
            echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
            exit();
        }     
         
    ?>
</div>

<br/>

</body>
      </html>


      <?php

if(isset($_POST['save'])){
  $stuID = $_POST["stuid"];
                if (isset($_POST["oldpwd"])){
                    $newMail = $_POST["stuemail"];
                    $newPhone = $_POST["stutel"];
                    $curPwd = $_POST["oldpwd"];
                    $newPwd = $_POST["stupwd"];
                    $stuRole = $_POST["sturole"];
        
                    global $mydb;
                    $mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$stuID' AND stuPwd = '$curPwd'");
                            
                    $cur = $mydb->executeQuery();
                    if($cur==false){
                        die(mysql_error());
                    }
                    $row_count = $mydb->num_rows($cur);//get the number of count
                    
                    if($row_count==1){
                        $row=mysqli_fetch_assoc($cur);
                        if ($row['stuMail'] == $newMail){
                            $mydb->setQuery("UPDATE tblusers SET stuPhone = '$newPhone', stuPwd = '$newPwd', stuRole = '$stuRole' WHERE stuID = '$stuID'");
                        }else{
                            $mydb->setQuery("UPDATE tblusers SET stuMail = '$newMail', stuPhone = '$newPhone', stuRole = '$stuRole', stuPwd = '$newPwd', isVerified = 0 WHERE stuID = '$stuID'");
                            $emailChanged = true;
                        }
                        
                        $cur = $mydb->executeQuery();
                        if($cur==false){
                            die(mysql_error());
                        }else{
                          echo "<script type = 'text/javascript'>";
                          echo "alert('Update Success!')";
                          echo "</script>";
                          echo "<meta http-equiv='Refresh' content = '0; url=index.php'>";
                          exit();
                        }
                    }else{
                            echo "<script type = 'text/javascript'>";
                            echo "alert ('Update Failed!')";
                            echo "</script>";
                            echo "<meta http-equiv='Refresh' content = '0; url=index.php'>";
                            exit();
                    }
    
                }else{
                        echo "<script type = 'text/javascript'>";
                        echo "alert ('Update Failed! Incorrect Password!')";
                        echo "</script>";
                        echo "<meta http-equiv='Refresh' content = '0; url=index.php'>";
                        exit();
                }

}
 
 ?> 


