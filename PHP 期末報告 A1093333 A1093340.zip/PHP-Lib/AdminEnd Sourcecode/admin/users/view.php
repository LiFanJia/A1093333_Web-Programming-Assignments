﻿<?php  
  if (!isset($_SESSION['stuID'])){
  redirect(web_root."admin/index.php");
 }
 
$stuID = isset($_GET['id']) ? $_GET['id'] : '';

if($stuID==''){
   redirect("index.php");
}


  $user = New User();
  $singleuser = $user->single_user($stuID);

 
  ?>

<head>

<style>

    body{
        background:#EAFFFB;


    }
    .container{
        border: ridge 5px;;
        background: lightgrey;
        

    }
  .card-header{
        background: rgb(105,105,105,0.7);
        text-align:center;
        font-size:45px;
        border: 5px solid #EAFFFB ;
        padding:  0em 1em;
        border-radius: 16px;
        
        line-height: 2;
        -webkit-box-decoration-break: clone;
        -o-box-decoration-break: clone;
         box-decoration-break: clone;
    }
    .small{
        padding: 12px 20px;
        margin: right;
        text-align-last:left;
        
       

    }
    .col-md-6{
        font-size:30px;
        text-align-last: left;
    }
 .col-lg-6{
        font-size:30px;
        text-align-last: left;
    }
    .form-group{
     
        /* font-size: 25px;
        padding: 12px 20px;
        margin: 8px;
        margin-right: 15px;
        margin-left:15px;
        margin bottom: 8px; */
        width: 30%;
        padding: 12px 20px;
        margin: 8px 0;
        display: block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        
    }



    
    .form-control{

        width: 50%;
        padding: 12px 20px;
        margin: 8px;
        margin-right: 15px;
        margin-left:15px;
        /* box-sizing: border-box */
        border: 5px;
        font-size:20px;
        text-align:right;
        float: right;
       
       
    }
    .input-group{
        
        width: 50%;
        padding: 12px 20px;
        border: 5px;
        font-size:30px;
        text-align:right;
        float: right;

    }
    .btn{
     
        /* top:20%; */
        background-color:#1E51E5;
        font-size:33px;
        padding: 15px 20px;
        margin-left:20px;
        border-radius: 10px;
        border-width: 20px;
        /* font-size: 16px; */
        border:none;
        text-align:center;
    }
    .btn:hover{
       
        color: white;
    }
   
</style>

</head>
<body>
<div class="container">  
  
<div class="container">
<div class="panel-body inf-content">
    <div class="row">
        <div class="col-lg-6">


         <a  data-target="#myModal" data-toggle="modal" href=""  >
            <img alt="click here to change image" style="width: 100%"
             title="" class="img-circle img-thumbnail isTooltip" src="<?php echo web_root.'admin/dist/'. $singleuser->PicLoc;?>"  > 
         </a>  

         
        </div>
        <div class="card-header">
            <h1><strong>User Profile</strong></h1><br> 
                        
                  <div class="form-group">
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "U_NAME">Name:</label>

                      <div class="col-md-8">
                         <input id="stuID" name="stuID" type="Hidden" value="<?php echo $singleuser->stuID; ?>"> 
                         <input class="form-control input-sm" id="U_NAME" name="U_NAME" placeholder=
                            "Student Name" type="text" value="<?php echo $singleuser->stuName; ?>" readonly>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "U_USERNAME">Student ID:</label>

                      <div class="col-md-8">
                        <input name="deptid" type="hidden" value="">
                         <input class="form-control input-sm" id="U_USERNAME" name="U_USERNAME" placeholder=
                            "stuID" type="text" value="<?php echo $singleuser->stuID; ?>" readonly>
                      </div>
                    </div>
                  </div>  
        </div>
    </div>
</div>
</div>
            

     <!-- Modal -->
          <div class="modal fade" id="myModal" tabindex="-1">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="myModalLabel">Choose Image</h4>
                  <div class="col-md-4 strecth">         
                      
                      < <div class="col-md-4 strecth">         
                      
                      <img id="blah" title="profile image" class="img-hover"    src="<?php echo web_root.'asset/images/emptyphoto.jpg'; ?>" width="300px" height="200px"> 
                       
                     <input type="file" name="picture"  id="imgInp" /> 
             </div>
 
           </div>
 
           </div>
                  <button class="close" data-dismiss="modal" type=
                  "button">×</button>

                </div>

                <form action="controller.php?action=photos" enctype="multipart/form-data" method="post">
                  <div class="modal-body">
                    <div class="form-group">
                      <div class="rows">
                        <div class="col-md-12">
                          <div class="rows">
                            <div class="col-md-8">
                            <input class="mealid" type="hidden" name="user_id" id="user_id" value="<?php echo $stuID ?>">
                              <input name="MAX_FILE_SIZE" type=
                              "hidden" value="1000000"> <input id=
                              "photo" name="photo" type=
                              "file">
                            </div>

                            <div class="col-md-4"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="modal-footer">
                    <button class="btn btn-default" data-dismiss="modal">Close</button> <button class="btn btn-primary"
                    name="savephoto" type="submit">Upload Photo</button>
                  </div>
                </form>
              </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
          </div><!-- /.modal -->

 