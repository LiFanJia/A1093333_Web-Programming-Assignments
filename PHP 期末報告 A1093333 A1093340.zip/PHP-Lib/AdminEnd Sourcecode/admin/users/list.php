<?php
	 if (!isset($_SESSION['stuRole'])=='Administrator'){
      redirect(web_root."index.php");
     }

?>   

<head>

<style>


    body{
        background: #EAFFFB;


    }
	.container{
        border:  ridge;
        background: lightgrey;
        font-size:  30px;
        font-weight: bold;
        text-align:left;

    }
	.card-header{
        background: rgb(105,105,105,0.7);
        text-align:center;
        font-size:25px;
        border: 5px solid #EAFFFB ;
        padding:  20px;
        //border-radius: 16px;
        
        line-height: 2;
        -webkit-box-decoration-break: clone;
        -o-box-decoration-break: clone;
         box-decoration-break: clone;
    }
	.card-body{

	 background: #f6e8dc;
	   text-align:left;
	   
	   padding:7px;
	   font-size:18px;
   }
   
   
</style>

</head>
<body>
<div class="container">  

          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h3>List of Users <a href="index.php?view=add" class="btn btn-primary btn-sm" ><i class="fa fa-plus"></i> New</a></h3>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover"  id="dataTable" cellspacing="0"  width="100%" style="white-space: nowrap;">
				  <thead> 
					  <p>
				  		<th> <h2>Account Name</h2></th>
				  		<th><h2>Username</h2></th>
				  		<th><h2>Role</h2></th>
				  		<th><h2>Action</h2></th>  
						  
					</p>	  
				  </thead> 
				  <tbody>
				  	<?php 
				  		// $mydb->setQuery("SELECT * 
								// 			FROM  `tblusers` WHERE TYPE != 'Customer'");
				  		$mydb->setQuery("SELECT * 
											FROM  `tblusers`");
				  		$cur = $mydb->loadResultList();

						foreach ($cur as $result) {
				  		echo '<tr>'; 
				  		echo '<td><h2>' . $result->stuName.'</a><hr width="100%"></td></h2>';
				  		echo '<td><h2>'. $result->stuMail.'</a><hr width="100%"></td></h2>';
				  		echo '<td><h2>'. $result->stuRole.'</a><hr width="100%"></td></h2>';

			?>
					
				</br>
			<?php
					
						

				  		if ($result->stuRole=="SystemAdministrator") {
				  			# code...
				  			$btn = '<a title="Edit" href="index.php?view=edit&id='.$result->stuID.'" class="btn btn-primary btn-sm  " ><i class="fa fa-edit"></i> Edit</a> <a title="Edit" href="index.php?view=changepassword&id='.$result->stuID.'" class="btn btn-success btn-sm  " ><i class="fa fa-lock"></i> Change Password</a> <a title="View" href="index.php?view=view&id='.$result->stuID.'" class="btn btn-info btn-sm  " ><i class="fa fa-edit"></i> View</a>';

				  		}else{
				  			$btn= '<a title="Edit" href="index.php?view=edit&id='.$result->stuID.'" class="btn btn-primary btn-sm  " ><i class="fa fa-edit"></i> Edit</a> 
				  					 <a title="Delete" href="controller.php?action=delete&id='.$result->stuID.'" class="btn btn-danger btn-sm  " ><i class="fa fa-trash"></i> Delete</a>';
				  		}
				  		echo '<td > '.$btn.'</td>';
				  		echo '</tr>';
				  	} 
				  	?>
				  </tbody>
					
				</table> 
			</div>
		</div>   