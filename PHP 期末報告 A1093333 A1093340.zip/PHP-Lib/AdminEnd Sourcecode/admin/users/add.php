<?php 
if (!isset($_SESSION['stuRole'])=='Administrator'){
     redirect(web_root."index.php");
    }

// $autonum = New Autonumber();
// $res = $autonum->single_autonumber(2);

?> 

<html>
<head>

<link rel = "icon" href = /img/login.png type = "image/x-icon">

<title>Add New User</title>

<style>

    body {
    margin : 0;
    padding : 0;
    font-family : Helvetica;
    background : #EAFFFB;
    height : 100vh;
    }



    .container{
        border: double black;
        background: lightgrey;


        

    }
    font{
        font-style: normal;
        font-weight: normal;


    }


        
    .center {
    position : relative;
    top : 0%;
    left : 50%;
    transform : translate(-50%,0%);
    width : 400px;
    background : #fff;
    border-radius : 10px;
    }

    .center h1{
    text-align : center;
    padding : 20px 0 20px 0;
    border-bottom : 1px solid silver;
    }

    .center form {
    padding : 0 40px;
    box-sizing : border-box;
    }

    form .txt_field{
    position : relative;
    border-bottom : 2px solid #adadad;
    margin : 30px 0;
    }

    .txt_field input{
    width : 100%;
    padding : 0 5px;
    height : 40px;
    font-size : 16px;
    border : none;
    background : none;
    outline : none;
    }

    .txt_field label{
    position : absolute;
    top : 50%;
    left : 5px;
    color : #adadad;
    transform : translateY(-50%);
    font-size = 16px;
    pointer-events : none;
    transition : .5s;
    }

    .txt_field label.birth{
    position : absolute;
    top : 50%;
    left : 5px;
    color : #adadad;
    transform : translateY(-50%);
    font-size = 16px;
    top : -5px;
    }

    .txt_field span::before{
    content : ' ';
    position : absolute;
    top : 40px;
    left : 0;
    width : 100%;
    height : 2px;
    background : #2691d9;
    }

    .txt_field input:focus ~ label, .txt_field input:valid ~ label{
    top : -5px;
    color : #2691d9;
    }

    .txt_field input:focus ~ span::before, .txt_field input:valid ~ span::before{
    width : 100%;
    }

    .pass{
    margin : -5px 0 20px 5px;
    color : #2691d9;
    cursor : pointer;
    }

    .pass:hover{
    text-decoration : underline;
    }

    .login_page{
    margin : 30px 0;
    text-align : center;
    font-size : 16px;
    color : #666666;
    }

    .login_page a{
    color : #2691d9;
    text-decoration : none;
    }

    .login_page a:hover{
    text-decoration : underline;
    }

    .header {
    overflow: hidden;
    padding: 20px 10px;
    }

    .header a {
    margin : 0 10px;
    background-color: #ffffff;
    float: left;
    color: black;
    text-align: center;
    padding: 12px;
    text-decoration: none;
    font-size: 15px;
    line-height: 0px;
    border-radius: 4px;
    }

    .header a.logoimg {
    margin : -10px 20px;
    }

    .header a.logotxt {
    margin : 8px -20px;
    font-size : 25px;
    font-weight : bold;
    }

    .header a:hover {
    background-color: #ddd;
    color: black;
    }

    .header a.active {
    background-color: #2691d9;
    color: white;
    }

    .header-right {
    float: right;
    }

    @media screen and (max-width: 500px) {
    .header a {
    float: none;
    display: block;
    text-align: left;
    }
    .header-right {
    float: none;
    }
    }

    </style>

    </head>

    <body>



    <div class = "center">
    <h1> Add New User </h1>
    <center><img src = /img/ourLibrary.png width = 50% height = 50%><center>

    <form action="controller.php?action=add" method="POST" onsubmit="return validateRetypePassword()">
    <div class = "usr-data">

    <div class = "txt_field">
    <input type = "text" name = "user_name" required>
    <label> Full Name </label>    
    <span></span>
    </div>

    <div class = "txt_field">
    <input type = "text" name = "user_id" required>
    <label> StudentID </label>    
    <span></span>
    </div>

    <div class = "txt_field">
    <input type = "email" name = "user_email" required>
    <label> Email Address </label>    
    <span></span>
    </div>

    <div class = "txt_field">
    <input type = "tel" name = "user_tel" required>
    <label> Phone Number </label>    
    <span></span>
    </div>

    <div class = "txt_field">
    <label class = "birth"> Date of Birthday </label>
    <input type = "date" name = "user_birth" id = "user_birth" value = " " min="1970-01-01" max="2021-12-31"required>
    <span></span>
    </div>

    <div class = "txt_field">
    <input type = "password" name = "user_pwd"required>
    <label> Password </label>    
    <span></span>
    </div>

    <div class = "txt_field">
    <input type = "text" name = "user_role"required>
    <label> Role </label>    
    <span></span>
    </div>

    </div>
            
             <div class="form-group">
                    <div class="col-md-8">
                      <h3><label class="col-md-4 control-label" for=
                      "idno"></label></h3>

                        </br></br>

                      <div class="col-md-8">
                       <button class="btn btn-primary" id="usersave" name="save" type="submit" ><i class="fa fa-save"></i>  Save</button> 
                          <a href="index.php" class="btn btn-info"><span class="fa fa-arrow-left"></span> List of Users</a>

                          </br></br> </br></br>
                       </div>
                    </div>
                  </div>

</form>
</body>

</html>