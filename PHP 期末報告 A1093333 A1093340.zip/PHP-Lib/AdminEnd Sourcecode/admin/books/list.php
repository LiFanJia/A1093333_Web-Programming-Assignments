<head>

<style>

body{
        background: #EAFFFB;


    }
    .container{
        border: ridge;
   		width:100%;
		

		background: #f6e8dc;
		text-align:left;
		font-size:20px;


        /* align:center; */

    }
    .card-header{
        background: rgb(105,105,105,0.7);
        text-align:center;
        font-size:20px;
        border: 5px solid #EAFFFB ;
        /* padding:  0em 1em; */
		padding: 20px;
		margin-top:0px;
		margin-bottom:0px;
		
        border-radius: 16px;
        
        line-height: 2;
        -webkit-box-decoration-break: clone;
        -o-box-decoration-break: clone;
         box-decoration-break: clone;
    }
   .card-body{
	   text-align:left;
	   margin-right:10px;
	   padding:7px;
	   font-size:15px;
   }
    .col-md-6{
        font-size:30px;
        text-align-last: left;
    }
    .form-group{
     
        width: 30%;
        padding: 12px 20px;
        margin: 8px 0;
        display: block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        
    }

  
  

</style>

</head>
<body>
<div class="container">  
 
			  <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h1 class="m-0 font-weight-bold text-primary">List of Books 
             <?php if ($_SESSION['stuRole']=="SystemAdministrator" || $_SESSION['stuRole']=="Administrator") { ?>
              	<a href="index.php?view=add" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> New</a>
              <?php } ?>
          	</h1>
            </div>
            <div class="card-body">
              <div class="table-responsive">



			    <!-- <form action="controller.php?action=delete" Method="POST">  					 -->
				<table id="dataTable" class="table table-bordered table-hover" width="100%" cellspacing="0"  >
				
				  <thead>
				  	<tr> 
						<th>IBSN</th>
						<th>Title</th>
						<th>Description</th> 
						<th>Category</th> 
						<th>Author</th> 
						<th>Price</th>
						<th>Status</th>
						<!-- <th>Quantity</th> -->
						<thAction</th>
				  	</tr>	
				  </thead>
				  <tbody>
				  	<?php
				  	// `AccessionNo`, `BookTitle`, `BookDesc`, `Author`, `PublishDate`, `BookPublisher`, `Category`, `BookPrice`, `BookQuantity`, `Status`, `BookType`, `DeweyDecimal`, `OverAllQty`, `Donate`, `Remarks`
				  	
					  		// $mydb->setQuery("SELECT *, sum(BookQuantity) as qty FROM `tblbooks` GROUP BY BookTitle");
				  	$mydb->setQuery("SELECT * FROM `tblbooks`");
						  	loadresult();
					
				  		function loadresult(){
					  		global $mydb;
					  		$cur = $mydb->loadResultlist();
							foreach ($cur as $result) {
						  		echo '<tr>'; 
						  		// echo '<td ><input type="checkbox" name="selector[]" id="selector[]" value="'.$result->SUBJ_ID. '"/>
						  		// 		<a href="index.php?view=edit&id='.$result->SUBJ_ID.'">' . $result->SUBJ_CODE.'</a></td>';
								  echo '<td><h3>' . $result->IBSN.'</h3></td></td>';
								  echo '<td ><h3>'. $result->BookTitle.'</h3></td>';
								  echo '<td><h3>'.  $result->BookDesc.'</h3><HR SIZE="4" NO SHADE></td>'; 
								  echo '<td><h3>'. $result->Category.'</h3></td></td>'; 
								  echo '<td><h3>'. $result->Author.'</h3></td></td>';
								  echo '<td><h3>'. $result->BookPrice.'</h3></td></td>';
								  echo '<td><h3>'. $result->Status.'</h3></td></td>';
								// echo '<td>'. $result->qty.'</td>';

								if ($_SESSION['stuRole']=="SystemAdministrator" || $_SESSION['stuRole']=="Administrator") {
				  			# code...
						  			$btn= '<a title="Edit" href="index.php?view=edit&id='.$result->IBSN.'" class="btn btn-primary btn-sm  " ><i class="fa fa-edit"></i> Edit</a>  
						  			 
						  			<a title="View Book Details" href="index.php?view=view&id='.$result->IBSN.'" class="btn btn-info btn-sm  " ><i class="fa fa-info"></i> View</a>
						  					 <a title="Delete" href="controller.php?action=delete&id='.$result->IBSN.'" class="btn btn-danger btn-sm  " ><i class="fa fa-trash"></i> Delete</a>';
						  	 
						  		}else{
						  			$btn='No Action';
						  			
				  				}
				  				echo '<td > '.$btn.'</td>';

						  		echo '</tr>';
					  		}
					  	} 
				  	?>
				  </tbody>
				
				</table>
				<?php
				// if($_SESSION['ACCOUNT_TYPE']=='Administrator'){
				// 		echo '
				// <div class="btn-group">
				//   <a href="index.php?view=add" class="btn btn-default"><span class="glyphicon glyphicon-plus-sign"></span> New</a>
				//   <button type="submit" class="btn btn-default" name="delete"><span class="glyphicon glyphicon-trash"></span> Delete Selected</button>
				// </div>';
			// }
				?>
				<!-- </form>  -->

			</div>
		</div>
	</div>
	</div>
  </body>	
