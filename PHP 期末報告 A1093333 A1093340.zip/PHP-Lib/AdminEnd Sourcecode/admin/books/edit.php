<?php

$id = $_GET['id'];
$book = new Book();
$object = $book->single_books($id);

?>

<head>

<style>

    body{
        background: #40E0D0;


    }
    .container{
        border: double black;
        background: lightgrey;
        

    }
   
    font{
        font-style: normal;
        font-weight: normal;
        font-size: 80px;


    }
    .col-md-6{
        border: hidden;
        background:lightgrey;
        text-align:center;
        width: 100;
        height:50;
        font-size: 30px;
        text-align: justify;
    

    }
</style>

</head>
<body>
<div class="container">  
 
  <div class="card shadow mb-4">
  <div class="card-header py-3">
    <h2 class="m-0 font-weight-bold text-primary">Modify Book</h2>
  </div>
  <div class="card-body">
    <div class="table-responsive">

        <form class="form-horizontal well span4" action="controller.php?action=edit&id=<?php echo $id;?> enctype = 'multipart/form-data'" method="POST"> 
            <?php
                global $mydb;

                $mydb->setQuery("SELECT * FROM tblbooks WHERE IBSN = $id");
                
                $cur = $mydb->executeQuery();
                if($cur==false){
                    die(mysql_error());
                }                
                    $row=mysqli_fetch_assoc($cur);
                        echo "<a href ='".$row['imgPath']."'>";
                        echo "<img src='".$row['imgPath']."' width='30%'>";
                        echo "</a>";
                        echo "<br/>";
                echo "<a href = 'cover.php?id=$id'> Change Cover </a>";            
            ?>
          <div class="col-md-12"> 
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="AccessionNo">ISBN&nbsp&nbsp</label><input class="form-control " id="IBSN" name="IBSN" type="text" style="height:30px; width:200px;" placeholder="Enter IBSN" readonly="off" value="<?php echo $object->IBSN;?>" /></div>
        </div> 
    </div>
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookTitle">Title&nbsp&nbsp</label><input class="form-control " id="BookTitle" name="BookTitle" type="text" style="height:30px; width:200px;" placeholder="Enter Title" value="<?php echo $object->BookTitle;?>"/></div>
        </div>
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookDesc">Description&nbsp&nbsp</label><input class="form-control " id="BookDesc" name="BookDesc" type="text" style="height:30px; width:200px;" placeholder="Enter Description" value="<?php echo $object->BookDesc;?>"/></div>
        </div>
    </div>  
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="Author">Author&nbsp&nbsp</label><input class="form-control " id="Author" name="Author" type="text" style="height:30px; width:200px;"  placeholder="Enter Author" value="<?php echo $object->Author;?>"/></div>
        </div>
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="PublishDate">Published Date&nbsp&nbsp</label><input class="form-control " id="datepicker" name="PublishDate" type="text" style="height:30px; width:200px;" placeholder="Select Date" value="<?php echo $object->PublishDate;?>" readonly /></div>
        </div>
    </div>  
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookPublisher">Publisher&nbsp&nbsp</label><input class="form-control " id="BookPublisher" name="BookPublisher" type="text" style="height:30px; width:200px;"  placeholder="Enter Publisher" value="<?php echo $object->BookPublisher;?>"/></div>
        </div>
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="Category">Category&nbsp&nbsp</label>
                 <select class="form-control " style="height:30px; width:200px;" name="Category" id="Category">
                      <?php
                      $categ = new Category();
                      $cur = $categ->listofcategory(); 
                      foreach ($cur as $category) {
                        if ($category->Category == $object->Category) {
                          # code...
                          echo '<option SELECTED>'.$category->Category.' </option>';
                        }else{
                          echo '<option>'.$category->Category.' </option>';
                        }
                      }

                   ?>
              
            </select> 
          </div>
        </div>
    </div> 

    <div class="form-row">
        <div class="col-md-6">
        <div class="form-group"><label class="small mb-1" for="DDecimal">Dewey Decimal&nbsp&nbsp</label><input class="form-control " id="DDecimal" name="DDecimal" type="text" style="height:30px; width:200px;" placeholder= "Enter Dewey Decimal Number" readonly="true" value="<?php echo $object->DeweyDecimal;?>"/></div>
        </div>
            <!-- <div class="form-group"><label class="small mb-1" for="Decimal">Dewey Decimal&nbsp&nbsp</label><input class="form-control " id="Decimal" name="Decimal" type="text" style="height:30px; width:200px;" placeholder="Enter Dewey Decimal" readonly="true" value="<?php echo $object->DeweyDecimal;?>"/></div>
        </div> -->
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="inputConfirmPassword">Type</label> 
             <select class="form-control input-sm" name="BookType" style="height:30px; width:200px;" id="BookType">
              <option <?php echo ($object->BookType=='Fiction') ? 'SELECTED': '' ?>>Fiction</option>
              <option <?php echo ($object->BookType=='Non-Fiction') ? 'SELECTED': '' ?>>Non-Fiction</option>  
              <option <?php echo ($object->BookType=='Unknown') ? 'SELECTED': '' ?>>Unknown</option>  
          </select> </div>
        </div>
    </div>   
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookPrice">Price&nbsp&nbsp</label><input class="form-control " id="BookPrice" name="BookPrice" type="text" style="height:30px; width:200px;" placeholder="Enter Price" value="<?php echo $object->BookPrice;?>"/></div>
            
        </div>
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="Remarks">Remarks&nbsp&nbsp</label><input class="form-control " id="Remarks" name="Remarks" type="text"  style="height:30px; width:200px;" aria-describedby="emailHelp" placeholder="Enter Remarks" value="<?php echo $object->Remarks;?>" /></div>
        </div>   
    </div>   
</div>



       <div class="form-group">
              <div class="col-md-8">
                <label class="col-md-4 control-label" for=
                "idno"></label>

                <div class="col-md-8">
                  <button class="btn btn-primary" name="savecourse"  style="height:50px; width:60px;" type="submit" ><span class="fa fa-save"></span> Save</button>
                  
                </div>
              </div>
            </div>
</form> 

</div>
</div>
</div>
  </div>
</body>