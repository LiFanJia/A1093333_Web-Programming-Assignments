<head>

<style>

<style>

body{
    background: #EAFFFB;


}
.container{
    border: double, 3px;
    background: lightgrey;
    /* align:center; */

}
.card-header{
    background: rgb(105,105,105,0.7);
    text-align:center;
    font-size:45px;
    border: 5px solid #EAFFFB ;
    padding:  0em 1em;
    border-radius: 16px;
    
    line-height: 2;
    -webkit-box-decoration-break: clone;
    -o-box-decoration-break: clone;
     box-decoration-break: clone;
}
.small{
    padding: 12px 20px;
    margin: right;
    text-align-last:left;
    
   

}
.col-md-6{
    font-size:30px;
    text-align-last: left;
}
.form-group{
 
    /* font-size: 25px;
    padding: 12px 20px;
    margin: 8px;
    margin-right: 15px;
    margin-left:15px;
    margin bottom: 8px; */
    width: 30%;
    padding: 12px 20px;
    margin: 8px 0;
    display: block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    
}




.form-control{

    width: 50%;
    padding: 12px 20px;
    margin: 8px;
    margin-right: 15px;
    margin-left:15px;
    /* box-sizing: border-box */
    border: 5px;
    font-size:20px;
    text-align:right;
    float: right;
   
   
}
.input-group{
    
    width: 50%;
    padding: 12px 20px;
    border: 5px;
    font-size:30px;
    text-align:right;
    float: right;

}
.btn{
 
    /* top:20%; */
    background-color:#1E51E5;
    font-size:33px;
    padding: 15px 20px;
    margin-left:20px;
    border-radius: 10px;
    border-width: 20px;
    /* font-size: 16px; */
    border:none;
    text-align:center;
}
.btn:hover{
   
    color: white;
}
    
</style>

</head>
<body>
 <div class="container">   
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h2 class="m-0 font-weight-bold text-primary">Add New Book</h2>
            </div>
            <div class="card-body">
              <div class="table-responsive">


              <form class="form-horizontal well span4" action="controller.php?action=add" method="POST" autocomplete="off">
 <div class="col-md-12"> 
    <div class="form-row">
    <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="IBSN">IBSN</label>
            <input class="form-control " id="IBSN" name="IBSN" type="text" placeholder="Enter IBSN" /></div>
        </div> 
    </div>
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookTitle">Title</label>
            <input class="form-control " id="BookTitle" name="BookTitle" type="text" placeholder="Enter Title" /></div>
        </div>
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookDesc">Description

            </label><input class="form-control " id="BookDesc" name="BookDesc" type="text" placeholder="Enter Description" /></div>
        </div>
    </div>  
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="Author">Author</label>
            <input class="form-control " id="Author" name="Author" type="text" placeholder="Enter Author" /></div>
            <div class="form-group"><label class="small mb-1" for="inputConfirmPassword">Published Date</label>
            <div class='input-group date'><input type='date' class="form-control"  style="align:center" name="PublishDate" id="datepicker" placeholder="Select Date" data-dialog-mode="true"  />
            <span class="input-group-addon">
            </span>
        </div>
</br></br></br>
       
    </div>  
    <div class="form-row">
        
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookPublisher">Publisher</label><input class="form-control " id="BookPublisher" name="BookPublisher" type="text" placeholder="Enter Publisher" /></div>
        </div>

        <div class="col-md-6">
    <div class="form-row">
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="BookPrice">Price</label><input class="form-control " id="BookPrice" name="BookPrice" type="text" placeholder="Enter Price" /></div>
        </div>
        <div class="col-md-6">
            <div class="form-group"><label class="small mb-1" for="Remarks">Remarks</label><input class="form-control " id="Remarks" name="Remarks" type="text" aria-describedby="emailHelp" placeholder="Enter Remarks" /></div>
        </div>     
    </div>   
</div>

                    </br></br></br>
       <div class="form-group">
              <div class="col-md-8">
                <label class="col-md-4 control-label" for=
                "idno"></label>

               
           

                <div class="col-md-8">
                  <button class="btn btn-primary" name="savecourse" type="submit" ><span class="fa fa-save"></span> Save</button>
               <!--   <button class="btn btn-primary" name="saveandnewcourse" type="submit" ><span class="fa fa-save"></span> Save and Add new</button> -->
                </div>
              </div>
            </div>
            </br></br> </br></br>

         
            
    </form> 

        </div>
        </div>
        </div>
    </div>
  </body>