<?php
if(!isset($_GET['id'])){
    echo "<meta http-equiv='Refresh' content = '0; url=../index.php'>";
}

$id = $_GET['id'];

require("../../include/database.php");

// $phototmpname = $_FILES["photo"]["tmp_name"];
// echo $phototmpname;

$pathpart = pathinfo($_FILES['photo']['name']);
$extname = $pathpart['extension'];
$now = time();
// echo $extname."<br/>";

$finalphoto = "Photo_".time().'.'.$extname;
// echo $finalphoto."<br/>";
// echo $now;
global $mydb;

$mydb->setQuery("UPDATE tblbooks SET imgPath = '$finalphoto', imgDate = $now WHERE IBSN = $id");

$cur = $mydb->executeQuery();
if($cur==false){
    die(mysql_error());
}
    
$row=mysqli_fetch_assoc($cur);

if (copy($_FILES['photo']['tmp_name'], $finalphoto)){
    $cur = $mydb->executeQuery();
    if($cur==false){
        die(mysql_error());
        echo "<script type = 'text/javascript'>";
        echo "alert('Upload Photo Failed');";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content = '0; url=cover.php?id=$id'>";
    }else{
        echo "<script type = 'text/javascript'>";
        echo "alert('Photo Uploaded Successfully')";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content = '0; url=index.php?view=edit&id=$id'>";
    }
     
}else{
    echo "<script type = 'text/javascript'>";
        echo "alert('Upload Photo Failed');";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content='0; url=cover.php?id=$id'>";
}

?>