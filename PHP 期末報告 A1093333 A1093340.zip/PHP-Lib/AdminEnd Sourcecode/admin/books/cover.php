<?php
if(!isset($_GET['id'])){
    echo "<meta http-equiv='Refresh' content = '0; url=../index.php'>";
}

$id = $_GET['id'];

?>
<html>
</body>
    <h1>Upload Cover Photo<br/></h1>
    <?php
        echo "<form action = 'coverupload.php?id=$id' method = 'POST' enctype = 'multipart/form-data'>";
    ?>
    <input type = "file" name = "photo" accept = "image/*"></br>
    <input type = "submit">

    </form>
</body>
</html>