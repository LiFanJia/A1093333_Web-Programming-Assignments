<?php
require_once ("../include/initialize.php");

if (isset($_GET['action']) && $_GET['action'] != ''){
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

    if ($action == 'add'){
        global $mydb;

            if ($_POST['newName'] == "" OR $_POST['newEmail'] == "" OR $_POST['newPass'] == "") {
                $messageStats = false;
                message("All field is required!","error");
                redirect('register.php');
            }else{	
                $user = New User();
                $user->stuID		= $_POST['newID'];
                $user->stuName		= $_POST['newName'];
                $user->stuMail		= $_POST['newEmail'];
                $user->stuPhone		= $_POST['newTel'];
                $user->stuBirth		= $_POST['newBirth'];
                $user->stuPwd		=($_POST['newPass']);
                $user->stuRole		= "Student";
                $user->create(); 

                            // $autonum = New Autonumber(); 
                            // $autonum->auto_update(2);

                // message("New [". $_POST['user_name'] ."] created successfully!", "success");
                echo "<script type = 'text/javascript'>";
                echo "alert('Registration Success! Please Login!')";
                echo "</script>";
                echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
		exit();
                        
            }


    }
    
}else{
    echo "<meta http-equiv='Refresh' content = '0; url=register.php'>";
    exit();
}
?>