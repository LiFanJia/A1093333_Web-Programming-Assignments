<head>

<style>

    body{
        background: #40E0D0;


    }
    .container{
        border: double,darkgrey;
        background: lightgrey;
        

    }
    font{
        font-style: normal;
        font-weight: normal;


    }
    .card-body{

            border: 3px, black;
            background: coral;
            text-align:center;
            font-size:40px;

    }
</style>

</head>
<body>
<div class="container">  
 
 <h1 class="mt-4">Dashboard</h1>
                        
                      <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                               
                                    <a href="books/index.php"><div class="card-body">Available Books</div></a>
                                  
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                             
                            <div class="col-xl-3 col-md-6">
                              
                                    
                               
                                    <a href="users/index.php"><div class="card-body">User</div></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>


                                    <a href="borrow/borrowhis.php"><div class="card-body">Borrowed Books</div></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>   

                                   <div class="card-body">Inventory of Books</div>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                          
                            
                        <div class="card mb-4">
                            
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Book Title</th>
                                                <th>Description</th>
                                                <th>Category</th>
                                                <th>Quantity</th> 
                                            </tr>
                                        </thead> 
                                        <tbody>

                                            <?php 
                                                     $mydb->setQuery("SELECT *, sum(BookQuantity) as qty FROM `tblbooks` WHERE Status='Available' GROUP BY BookTitle");   
                                                    $cur = $mydb->loadResultlist();
                                                    foreach ($cur as $result) {
                                                        echo '<tr>';  
                                                        echo '<td >'. $result->BookTitle.'</td>';
                                                        echo '<td>'.  $result->BookDesc.'</td>'; 
                                                        echo '<td>'. $result->Category.'</td>';  
                                                        echo '<td>'. $result->qty.'</td>';


                                                        echo '</tr>';

                                                  
                                                }  
                                            ?>
                                        </tbody>
                                    </table>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>

                                </div>
                            </div>
                        </div>
