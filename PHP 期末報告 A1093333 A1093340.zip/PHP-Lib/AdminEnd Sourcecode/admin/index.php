<?php 
// require_once("include/initialize.php");
require_once ("../include/initialize.php");

 if (!isset($_SESSION['stuID'])){
  redirect(web_root."admin/login.php");
 }else{
	 if ($_SESSION['stuRole'] != "Administrator"){
        echo "<meta http-equiv='Refresh' content = '0; url=Catalogue.php'>";
		exit();
	 }
 } 

$content='home.php';

$view = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
switch ($view) {  
	default :
	  $content    = 'home.php';
}
 require_once("themes/templates.php");
?>