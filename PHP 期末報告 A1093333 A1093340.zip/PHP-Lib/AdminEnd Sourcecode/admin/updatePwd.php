<?php
//header already sent
//ob_start();

session_start();
require ('../include/database.php');

if (isset($_COOKIE['AthReset'])){
    if (isset($_POST["newPwd"])){
        $stuID = $_COOKIE['AthReset'];
        $newPass = $_POST["newPwd"];
        
        global $mydb;
    	$mydb->setQuery("UPDATE tblusers SET stuPwd = '$newPass' WHERE stuID = '$stuID'");
                
        $cur = $mydb->executeQuery();
        if($cur==false){
            echo "<script type = 'text/javascript'>";
            echo "alert ('Reset Password Failed!')";
            echo "</script>";
            echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
            die(mysql_error());
        }else{
            echo "<script type = 'text/javascript'>";
            echo "alert('Password has been reseted successfully!')";
            echo "</script>";
            echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
        }

    }else{
        echo "<script type = 'text/javascript'>";
        echo "alert ('Reset Password Failed!')";
        echo "</script>";    
        echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
        exit();
    }
}else{
    echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    exit();
}