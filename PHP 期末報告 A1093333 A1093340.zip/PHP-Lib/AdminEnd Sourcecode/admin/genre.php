<?php

session_start();
if (!isset($_SESSION['stuID'])){
    echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    exit();
}
require("../include/database.php");
    $stuID = $_SESSION['stuID'];

?>

<html>
<head>

<title>Genre - OurLibrary</title>

<style>

    body {
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : #EAFFFB;
        height : 100vh;
    }

    
    .center {
        width : 750px;
        background : #fff;
        border-radius : 10px;
        text-align: center;
        position: center;
        margin: auto;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .header {
        overflow: hidden;
        padding: 20px 10px;
    }

    .header a {
        margin : 0 10px;
        background-color: #ffffff;
        float: left;
        color: black;
        text-align: center;
        padding: 12px;
        text-decoration: none;
        font-size: 15px;
        line-height: 0px;
        border-radius: 4px;
    }

    .header a.logoimg {
        margin : -10px 20px;
    }

    .header a.logotxt {
        margin : 8px -20px;
        font-size : 25px;
        font-weight : bold;
    }

    .header a:hover {
        background-color: #ddd;
        color: black;
    }

    .header a.active {
        background-color: #2691d9;
        color: white;
    }

    .header-right {
        float: right;
    }

    @media screen and (max-width: 500px) {
        .header a {
            float: none;
            display: block;
            text-align: left;
        }
        .header-right {
            float: none;
        }
    }
    
    .hero {
    position: relative;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url(/img/Digital-Library-2048x1494.jpeg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    filter: brightness(60%);
    }
    .hero-content {
    position: relative;
    font-family: "Monserrat", sans-serif;
    color: white;
    text-align: center;
    margin: 0.625rem;
    }
    .hero-title {
    font-size: 3rem;
    font-weight: 600;
    margin-bottom: 0;
    }
    .hero-subtitle {
    font-size: 2rem;
    font-weight: 200;
    margin-top: 1rem;
    }
    .hero-button {
    background-color: #ae2d59;
    color: white;
    border: 1px solid #cb376a;
    margin-top: 5rem;
    padding: 0.9375rem1.875rem;
    font-family: "Monserrat", sans-serif;
    font-size: 1.125rem;
    font-weight: 200;
    cursor: pointer;
    }
    .hero-button:hover {
    background-color: #cb376a;
    border: 1px solid #db7598;
    }

    table, th, td{
        text-align: left;
    }

    th {
        height: 70px;
    }

    td {
        height: 80px;
        /* border:black; border-width:3px; border-style: solid; */
    }

    .titlebook {        
        border:black; 
        border-width:2px; 
        border-style: solid;
    }

    hr{
        width: 100%;
        background-color: black;
        border-color: black;  
    }
    
    .box{
        margin:20px;
        background-color: white;
    }

</style>

</head>

<body>

<div class = "header">
    <a class = "logoimg"> <img src = /img/ourLibrary.png width = 50px height = 40px></a>
    <a class = "logotxt">OurLibrary</a>
    <div class = "header-right">
        <a class = "active" href = "genre.php"> Genre</a>
        <a href = "Catalogue.php">Home</a>
        <a href = "mybook.php">My Books</a>
        <a href = "myacc.php">My Account</a>
        <a href = "logout.php">Logout</a>
    </div>
</div>

<div class = "box">
    <h2><b>&nbspGenre</b></h2>
</div>



<?php


    global $mydb;

	$mydb->setQuery("SELECT Category FROM tblcategory");

    
    echo "<table style= 'width: 100%' border = 1px>";
    echo "<thead><TR>";
        
    $cur = $mydb->executeQuery();
    if($cur==false){
        die(mysql_error());
    }
    
    while($row=mysqli_fetch_assoc($cur)){
        $category = $row['Category'];
        $mydb->setQuery("SELECT * FROM tblbooks WHERE Category = '$category'");
        $cur2 = $mydb->executeQuery();
        if($cur2==false){
            die(mysql_error());
        }else if ($mydb->num_rows($cur2) != 0){

            echo "<TH style = 'background-color:#5BA7AC;text-align:center' colspan=6>$category</TH>";
            echo "<TR><TD><b>Cover</b></TD>"; 
            echo "<TD><b>Title</b></TD>"; 
            echo "<TD><b>Author</b></TD>"; 
            echo "<TD><b>Publisher</b></TD>"; 
            echo "<TD><b>Published Date</b></TD>"; 
            echo "<TD><b>Rating</b></TD>"; 
            
            while($row2=mysqli_fetch_assoc($cur2)){
                echo "<TR><Td><a href ='books/".$row2['imgPath']."'>";
                echo "<img src='books/".$row2['imgPath']."' width='150px' height = '200px'>";
                echo "</a></TD>";
                $bno = $row2['BookID'];
                        
                echo "<TD><a href='catabook.php?bno=$bno'>".$row2["BookTitle"]."</a></TD>";
                echo "<TD>".$row2["Author"]."</TD>";
                echo "<TD>".$row2["BookPublisher"]."</TD>";
                echo "<TD>".$row2["PublishDate"]."</TD>";
                $mydb->setQuery("SELECT AVG(rating) as rate FROM tbltransaction2 WHERE bNo = $bno");
                $cur3 = $mydb->executeQuery();
                if($cur3==false){
                    die(mysql_error());
                }
                $row3=mysqli_fetch_assoc($cur3);
                $avgrate = $row3['rate'];

                if ($avgrate == ''){
                    $avgrate = 0;
                }

                echo "<TD>".$avgrate."</TD>";

                echo "</TR>";
                echo "<TR></TR>";
                echo "<TR></TR>";
                echo "<TR></TR>";
                echo "<TR></TR>";

                // if ($row["returnDate"] == ''){
                //     echo "<TD>Not Return Yet</TD>";
                // }else{
                //     echo "<TD>".$row["returnDate"]."</TD>";
                // }                
                
            }

        }
    

    }

?>