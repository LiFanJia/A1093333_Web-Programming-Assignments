<?php

session_start();
if (!isset($_SESSION['stuID'])){
    echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    exit();
}
require("../include/database.php");

    $stuID = $_SESSION["stuID"];

?>

<title>My Book - OurLibrary</title>

<style>

    body {
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : #EAFFFB;
        height : 100vh;
    }

    
    .center {
        width : 750px;
        background : #fff;
        border-radius : 10px;
        text-align: center;
        position: center;
        margin: auto;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .header {
        overflow:;
        padding: 20px 10px;
    }

    .header a {
        margin : 0 10px;
        background-color: #ffffff;
        float: left;
        color: black;
        text-align: center;
        padding: 12px;
        text-decoration: none;
        font-size: 15px;
        line-height: 0px;
        border-radius: 4px;
    }

    .header a.logoimg {
        margin : -10px 20px;
    }

    .header a.logotxt {
        margin : 8px -20px;
        font-size : 25px;
        font-weight : bold;
    }

    .header a:hover {
        background-color: #ddd;
        color: black;
    }

    .header a.active {
        background-color: #2691d9;
        color: white;
    }

    .header-right {
        float: right;
    }

    @media screen and (max-width: 500px) {
        .header a {
            float: none;
            display: block;
            text-align: left;
        }
        .header-right {
            float: none;
        }
    }
    
    .hero {
    position: relative;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    }

    .hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url(/img/Digital-Library-2048x1494.jpeg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    filter: brightness(60%);
    }

    .hero-content {
    position: relative;
    font-family: "Monserrat", sans-serif;
    color: white;
    text-align: center;
    margin: 0.625rem;
    }

    .hero-title {
    font-size: 3rem;
    font-weight: 600;
    margin-bottom: 0;
    }

    .hero-subtitle {
    font-size: 2rem;
    font-weight: 200;
    margin-top: 1rem;
    }

    .hero-button {
    background-color: #ae2d59;
    color: white;
    border: 1px solid #cb376a;
    margin-top: 5rem;
    padding: 0.9375rem1.875rem;
    font-family: "Monserrat", sans-serif;
    font-size: 1.125rem;
    font-weight: 200;
    cursor: pointer;
    }

    .hero-button:hover {
    background-color: #cb376a;
    border: 1px solid #db7598;
    }

    table, th, td{
        text-align: left;
    }

    th {
        height: 70px;
    }

    td {
        height: 80px;
        /* border:black; border-width:3px; border-style: solid; */
    }

    .titlebook {        
        border:black; 
        border-width:2px; 
        border-style: solid;
    }

    hr{
        width: 100%;
        background-color: black;
        border-color: black;  
    }

    .box{
        margin:20px;
        background-color: white;
    }

</style>

</head>

<body>
<div class = "header">
    <a class = "logoimg"> <img src = /img/ourLibrary.png width = 50px height = 40px></a>
    <a class = "logotxt">OurLibrary</a>
    <div class = "header-right">
        <a href = "genre.php"> Genre</a>
        <a href = "Catalogue.php">Home</a>
        <a class = "active" href = "mybook.php">My Books</a>
        <a href = "myacc.php">My Account</a>
        <a href = "logout.php">Logout</a>
    </div>
</div>

<div class = "box">
    <h2><b>&nbspMy Books</b></h2>
</div>

<br/>

<div class = "box">

    <?php
        global $mydb;
    	$mydb->setQuery("SELECT * FROM tbltransaction2 t, tblusers s, tblbooks b WHERE t.stuNo = s.stuNo AND t.bNo = b.bookID AND s.stuID = '$stuID'");
                
        $cur = $mydb->executeQuery();
        if($cur==false){
            die(mysql_error());
            echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
            exit();
        }else{
            // $row_count = $mydb->num_rows($cur);//get the number of count
            echo "<table style=' width:100%'>";
            echo "<TR style = 'background-color:#5BA7AC'><TD><b>Book ISBN</b></TD>"; 
            echo "<TD><b>Book Title</b></TD>"; 
            echo "<TD><b>Borrow Date</b></TD>"; 
            echo "<TD><b>Due Date</b></TD>"; 
            echo "<TD><b>Return Date</b></TD>"; 
            echo "<TD><b>Fine</b></TD>"; 
            echo "<TD><b>Rating</b></TD>";
            echo "<TD><b>Action</b></TD></TR>";
        
            while ($row=mysqli_fetch_assoc($cur)){
                echo "<TR><TD>".$row["IBSN"]."</TD>";
                echo "<TD>".$row["BookTitle"]."</TD>";
                echo "<TD>".$row["borrowDate"]."</TD>";
                echo "<TD>".$row["dueDate"]."</TD>";
                if ($row["returnDate"] == ''){
                    echo "<TD>Not Return Yet</TD>";
                }else{
                    echo "<TD>".$row["returnDate"]."</TD>";
                }                
                echo "<TD>".$row["fine"]."</TD>";
                echo "<TD>".$row["rating"]."</TD>";
                // echo "<TD>".$row["stuName"]."</TD><TD>".$row["stuID"]."</TD><TD>".$row["stuMail"]."</TD><TD>".$row["stuPhone"]."</TD><TD>".$row["stuBirth"]."</TD><TD><a href = 'deleteUser.php?stuNo=".$row["stuNo"]."'>Delete</a></TD><TD><a href = 'updateUser.php?stuNo=".$row["stuNo"]."'>Edit</a></TD><br/>";
                $rate = $row["rating"];
                if ($rate == '') {
                    $id = $row["TransID"];
                    echo "<TD><a href='rate.php?bid=$id'> Rate Now </a></TD></TR>";
                }
                

            }
        
            echo "</table>";
            echo "</div>";
            echo "<br/>";
        
           
        }
         
    ?>
</div>

<br/>

</body>


<?php
	include('footer.php');
?>