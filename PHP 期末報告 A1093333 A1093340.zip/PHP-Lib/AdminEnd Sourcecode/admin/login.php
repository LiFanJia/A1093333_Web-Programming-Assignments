<?php
require_once("../include/initialize.php");

 ?>
  <?php
 // login confirmation
 if (isset($_SESSION['stuID'])){
    if ($_SESSION['stuRole'] != "Administrator"){
          echo "<meta http-equiv='Refresh' content = '0; url=Catalogue.php'>";
          exit();
    }else{
        echo "<meta http-equiv='Refresh' content = '0; url=index.php'>";
        exit();   
    }
} 
?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Page Title - SB Admin</title>
        <link href="<?php echo web_root;?>admin/dist/css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
        <style>
        body {
            margin : 0;
            padding : 0;
            font-family : Helvetica;
            background : #EAFFFB;
            height : 100vh;
        }

        .center {
            position : absolute;
            top : 60%;
            left : 50%;
            transform : translate(-50%,-50%);
            width : 400px;
            background : #fff;
            border-radius : 10px;
        }

        .center h1{
            text-align : center;
            padding : 0 0 20px 0;
            border-bottom : 1px solid silver;
        }

        .center form {
            padding : 0 40px;
            box-sizing : border-box;
        }

        form .txt_field{
            position : relative;
            border-bottom : 2px solid #adadad;
            margin : 30px 0;
        }

        .txt_field input{
            width : 100%;
            padding : 0 5px;
            height : 40px;
            font-size : 16px;
            border : none;
            background : none;
            outline : none;
        }

        .txt_field label{
            position : absolute;
            top : 50%;
            left : 5px;
            color : #adadad;
            transform : translateY(-50%);
            font-size = 16px;
            pointer-events : none;
            transition : .5s;
        }

        .txt_field span::before{
            content : ' ';
            position : absolute;
            top : 40px;
            left : 0;
            width : 100%;
            height : 2px;
            background : #2691d9;
        }

        .txt_field input:focus ~ label, .txt_field input:valid ~ label{
            top : -5px;
            color : #2691d9;
        }

        .txt_field input:focus ~ span::before, .txt_field input:valid ~ span::before{
            width : 100%;
        }

        .pass{
            margin : -5px 0 20px 5px;
            color : #2691d9;
            cursor : pointer;
        }

        .pass:hover{
            text-decoration : underline;
        }

        input[type="submit"]{
            width : 100%;
            height : 50px;
            border : 1px solid;
            background : #2691d9;
            border-radius : 25px;
            font-size : 18px;
            color : #e9f4fb;
            font-weight : 700;
            cursor : pointer;
            outline : none;
        }

        input[type="submit"]:hover{
            border-color : #2691d9;
            transition : 0.5s;
        }

        .signup_page{
            margin : 30px 0;
            text-align : center;
            font-size : 16px;
            color : #666666;
        }

        .signup_page a{
            color : #2691d9;
            text-decoration : none;
        }
        
        .signup_page a:hover{
            text-decoration : underline;
        }

        .header {
            overflow: hidden;
            padding: 20px 10px;
        }

        .header a {
            margin : 0 10px;
            background-color: #ffffff;
            float: left;
            color: black;
            text-align: center;
            padding: 12px;
            text-decoration: none;
            font-size: 15px;
            line-height: 0px;
            border-radius: 4px;
        }

        .header a.logoimg {
            margin : -10px 20px;
        }

        .header a.logotxt {
            margin : 8px -20px;
            font-size : 25px;
            font-weight : bold;
        }

        .header a:hover {
            background-color: #ddd;
            color: black;
        }

        .header a.active {
            background-color: #2691d9;
            color: white;
        }

        .header-right {
            float: right;
        }

        @media screen and (max-width: 500px) {
            .header a {
                float: none;
                display: block;
                text-align: left;
            }
            .header-right {
                float: none;
            }
        }

            .form-group{
                position:center;

            }
            .card-body{

                position:center;
                border: double;
                background-color:lightblue;
                border-radius: 25px;
                padding: 20px;
                width: 400 px;
                height: 250px;
            }

        </style>



    </head>


    
<body>

<div class = "header">
    <a class = "logoimg"> <img src = /img/ourLibrary.png width = 50px height = 40px></a>
    <a class = "logotxt">OurLibrary</a>
    <div class = "header-right">
        <a class = "active" href = "login.php"> Login</a>
        <a href = "register.php">Register</a>
        <a href = "../aboutus.php">About Us</a>
        <a href = "../latestNews.php">Latest News</a>
        <a href = "../events.php">Events</a>
    </div>
</div>
</br></br>
<div class = "center">



<h1> Login </h1>
<center><img src = /img/ourLibrary.png width = 50% height = 50%><center>
    
<?php
date_default_timezone_set('Asia/Taipei');
echo '<br/>';

if(isset($_COOKIE["UID"])){
    $cookieID = $_COOKIE["UID"];
    echo '<p align = "center" style = "color:#666666;"> Welcome Back, '.$cookieID.'!<br/>';
}else{
    echo '<p align = "center" style = "color:#666666;"> Welcome, Please login! <br/>';
}

echo ('Date : ');
echo date ('m-d-Y', time());
echo "</p>"; 
?>


<form action = "" method = "POST">
    <div class = "txt_field">
        <input type = "text" name = yourID required>
        <label> Student ID </label>    
        <span></span>
    </div>

    <div class = "txt_field">
        <input type = "password" name = yourPass required>
        <label> Password </label>
        <span></span>
    </div>

    <div class = "pass"> <a href = "forgot.php">Forgot Password?</a></h5></div>
        
    <input type = "submit" value = "Login" name="btnLogin">
    
    <div class = "signup_page">
        Not a member? 
        <a href = "register.php">Register</a></div>

</form>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Library System 2019</div>
                            <div>
                              <!--   <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a> -->
                            </div>
                        </p>
                        </div>
                    </div>
                </footer>
            </div>
    </div>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo web_root;?>admin/dist/js/scripts.js"></script>
    </body>
</html>


 
<?php

if(isset($_POST['btnLogin'])){
  $stuid = trim($_POST['yourID']);
  $upass  = trim($_POST['yourPass']);
  $h_upass = sha1($upass);

   if ($stuid == '' OR $upass == '') {

      message("Invalid Username and Password!", "error");
      redirect("login.php");

    } else {
  //it creates a new objects of member
    $user = new User();
    //make use of the static function, and we passed to parameters

    $res = $user::userAuthentication($stuid, $upass);
    if ($res==true) {
       message("You're logged in as ".$_SESSION['stuRole'].".","success");
      if ($_SESSION['stuRole']=='Administrator'){   
        echo "<meta http-equiv='Refresh' content = '0; url=index.php'>";
      }else{
        echo "<meta http-equiv='Refresh' content = '0; url=Catalogue.php'>";
      }
    }else{
        echo "<script type = 'text/javascript'>";
        echo "alert('Wrong Student ID or Password!')";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    }
 }

}
 
 ?> 