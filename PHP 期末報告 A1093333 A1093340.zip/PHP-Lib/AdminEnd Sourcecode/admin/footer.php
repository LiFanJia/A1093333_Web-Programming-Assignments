<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content=
        "width=device-width, initial-scale=1" />
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  
<style>

.footer {
   position: relative;
   left: 0;
   top:0;
   bottom: 0;
   width: 98s%;
   background-color: white;
   border: 30px solid #5BA7AC;
   border-left-width:180px;
   border-right-width:180px;
   color: black;
   text-align: center;

   
        .fa:hover {
            opacity: 0.9;
        }
  
        .fa-facebook {
            background: #007bb5;
            color: white;
        }
  
        .fa-twitter {
            background: #cb2027;
            color: white;
        }
  
        .fa-instagram {
            background: #ff5700;
            color: white;
        }
  
        .fa {
            font-size: 40px;
            text-decoration: none;
        }
  
      
}


.boxy{
    position: relative;
    text-align: center;
    background-color: white;
    height:65px;
    font-size: 20px;
}


</style>
</head>
<body>


<div class = "boxy">
    <br/>
    <a href="#"> Back To Top </a>
</div>

<div class="footer">
  <p><center>
        <font face = "Arial">
        <h3>Online Library System</h3>
        <a href="aboutus.php"> About Us </a><br/><br/>
        <a href="mailto: ourlibrary8888@mail.thisschool.com"> Contact Us </a><br/><br/>
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-instagram"></a><br/><br/><br/>
        
        <h3>Setting</h3>
        <a href="mybook.php"> My Books </a><br/><br/>
        <a href="../myacc.php"> My Account </a><br/><br/>
        
        </font>
    </center>
</p>
</div>

</body>
</html> 
