<?php 
 require_once("../include/initialize.php");

// Four steps to closing a session
// (i.e. logging out)

// 1. Find the session
@session_start();

// 2. Unset all the session variables
unset( $_SESSION['stuID'] );
unset( $_SESSION['stuName'] );
unset( $_SESSION['stuMail'] );
unset( $_SESSION['stuPwd'] );
unset( $_SESSION['stuRole'] );


// redirect(web_root."admin/login.php?logout=1");

// header("Location: admin/login.php");
session_destroy();

if (!logged_in()) {?>

    <script type="text/javascript">
        window.location = "login.php";
    </script>

<?php
}

?>