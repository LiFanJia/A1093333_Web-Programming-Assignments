<?php
session_start();
if (!isset($_SESSION['stuID'])){
    echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    exit();
}
require("../include/database.php");
                $stuID = $_SESSION["stuID"];
                if (isset($_POST["oldpwd"])){
                    $newMail = $_POST["stuemail"];
                    $newPhone = $_POST["stutel"];
                    $curPwd = $_POST["oldpwd"];
                    $newPwd = $_POST["stupwd"];
        
                    global $mydb;
                    $mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$stuID' AND stuPwd = '$curPwd'");
                            
                    $cur = $mydb->executeQuery();
                    if($cur==false){
                        die(mysql_error());
                    }
                    $row_count = $mydb->num_rows($cur);//get the number of count
                    
                    if($row_count==1){
                        $row=mysqli_fetch_assoc($cur);
                        if ($row['stuMail'] == $newMail){
                            $mydb->setQuery("UPDATE tblusers SET stuPhone = '$newPhone', stuPwd = '$newPwd' WHERE stuID = '$stuID'");
                        }else{
                            $mydb->setQuery("UPDATE tblusers SET stuMail = '$newMail', stuPhone = '$newPhone', stuPwd = '$newPwd', isVerified = 0 WHERE stuID = '$stuID'");
                            $emailChanged = true;
                        }
                        
                        $cur = $mydb->executeQuery();
                        if($cur==false){
                            die(mysql_error());
                        }else{
                        
                            if ($emailChanged == true){
                                echo "<script type = 'text/javascript'>";
                                echo "alert('Please confirm your new email!')";
                                echo "</script>";
                                echo "<meta http-equiv='Refresh' content = '0; url=sendMail.php'>";
                                exit();
                            }else{
                                echo "<script type = 'text/javascript'>";
                                echo "alert('Update Success!')";
                                echo "</script>";
                                echo "<meta http-equiv='Refresh' content = '0; url=myacc.php'>";
                                exit();
                            }

                        }
                    }else{
                            echo "<script type = 'text/javascript'>";
                            echo "alert ('Update Failed!')";
                            echo "</script>";
                            echo "<meta http-equiv='Refresh' content = '0; url=myacc.php'>";
                            exit();
                    }
    
                }else{
                        echo "<script type = 'text/javascript'>";
                        echo "alert ('Update Failed! Incorrect Password!')";
                        echo "</script>";
                        echo "<meta http-equiv='Refresh' content = '0; url=myacc.php'>";
                        exit();
                }

?>