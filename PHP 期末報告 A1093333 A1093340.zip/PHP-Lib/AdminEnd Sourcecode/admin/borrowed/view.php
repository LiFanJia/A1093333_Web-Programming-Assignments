<?php

$id = $_GET['id'];
 
@$transaction = new Transaction();
@$trans = $transaction->single_transaction($id) ;
 





$book = new Book();
$object = $book->single_books($trans->IBSN);

?>
<head>

<style>

    body{
        background: #40E0D0;


    }
    .container{
        border: double, 3px;
        background: lightgrey;
        

    }
     
    font{
        font-style: normal;
        font-weight: normal;


    }
    font{
        font-style: normal;
        font-weight: normal;
        font-size: 35px;


    }
    .col-md-6{
        border: hidden;
        background:lightgrey;
        text-align:justify;
        width: 100;
        height:50;
        font-size: 35px;
    

    }
    .col-md-12{
        border: hidden;
        background:lightgrey;
        text-align:justify;
        width: 100;
        height:50;
        font-size: 40px;
    

    }
</style>

</head>
<body>
<div class="container">  

<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h1 class="m-0 font-weight-bold text-primary">Borrowed Books </h1>

  </div>
  <div class="card-body">
    



<div class="row">
            <div class="col-md-6">  
                  <div class="book-details" >Book Details</div> 
                  <HR  NOSHADE>

                  
                <div class="form-row">
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="IBSN">IBSN:  <?php echo  $object->IBSN ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div>  -->
                    <!-- <div class="col-md-9">  -->
                          <!-- <?php echo  $object->IBSN ?> -->
                    <!-- </div> -->
                    </div> 
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="BookTitle">Title:  <?php echo  $object->BookTitle ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9">  -->
                          <!-- <?php echo  $object->BookTitle ?> -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="BookDesc">Description:  <?php echo  $object->BookDesc ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9">  -->
                          <!-- <?php echo  $object->BookDesc ?> -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="Category">Category: <?php echo  $object->Category ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9">  -->
                          <!-- <?php echo  $object->Category ?> -->
                    </div>
                    <!-- <div class="col-md-3"> 
                          <label class="small mb-1" for="DeweyDecimal">Dewey Decimal:<?php echo  $object->DeweyDecimal ?></label>  
                          <HR  size="3" NOSHADE>
                     
                    </div> -->
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="BookType">Type: <?php echo  $object->BookType ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  $object->BookType ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="BookPrice">Price: <?php echo  $object->BookPrice ?></label> 
                          <HR  size="3" NOSHADE>

                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  $object->BookPrice ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="Author">Author: <?php echo  $object->Author ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  $object->Author ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="BookPublisher">Publisher: <?php echo  $object->BookPublisher ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  $object->BookPublisher ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="PublishDate">Date Published: <?php echo  $object->PublishDate ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  $object->PublishDate ?></p>  -->
                    </div>
                </div> 
            </div> 
            <!-- borrowers side -->
            <div class="col-md-6">
              <?php
              // SELECT `IDNO`, `BorrowerId`, `Firstname`, `Lastname`, `MiddleName`, `Address`, `Sex`, `ContactNo`, `CourseYear`, `BorrowerPhoto`, `BorrowerType`, `Stats`, `BUsername`, `BPassword` FROM `tblborrower` WHERE 1 
           
                  @$borrower = new Borrower();
                  @$res = $borrower->single_borrower($trans->BorrowerId) ;
          
              ?>
              <div class="book-details"><h2>Borrower Information</h2></div> 
              <HR  size="3" NOSHADE>
                <div class="form-row">
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="BorrowerId">Borrower ID:<?php echo  isset($res->BorrowerId) ? $res->BorrowerId: 'None'; ?></label>  
                          <HR  size="3" NOSHADE>
                     </div> 
                    <div class="col-md-9"> 
                          <!-- <p><?php echo  isset($res->BorrowerId) ? $res->BorrowerId: 'None'; ?></p>  -->
                          <input type="hidden" name="BorrowerId" value="<?php echo isset($res->BorrowerId) ? $res->BorrowerId: 'None'; ?>">
                          <input type="hidden" name="IBSN" value="<?php echo $id;?>">
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="Firstname">First Name: <?php echo  isset($res->Firstname) ? $res->Firstname: 'None'; ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->Firstname) ? $res->Firstname: 'None'; ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="MiddleName">Middle Name: <?php echo  isset($res->MiddleName) ? $res->MiddleName : 'None'; ?></p> </label>  
                          <HR  size="3" NOSHADE>
<!-- 
                     </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->MiddleName) ? $res->MiddleName : 'None'; ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="Lastname">Last Name: <?php echo  isset($res->Lastname) ? $res->Lastname: 'None'; ?></label>  
                          <HR  size="3" NOSHADE>

                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->Lastname) ? $res->Lastname: 'None'; ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="Address">Address: <?php echo  isset($res->Address) ? $res->Address: 'None'; ?></p> </label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->Address) ? $res->Address: 'None'; ?></p>  -->
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="Sex">Sex: <?php echo  isset($res->Sex) ? $res->Sex : 'None'; ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->Sex) ? $res->Sex : 'None'; ?></p>  -->
                         
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="ContactNo">Contact Number: <?php echo  isset($res->ContactNo) ? $res->ContactNo : 'None'; ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->ContactNo) ? $res->ContactNo : 'None'; ?></p>  -->
                
                    </div>
                    <div class="col-md-3"> 
                          <label class="small mb-1" for="CourseYear">Course/Year: <?php echo  isset($res->CourseYear) ?$res->CourseYear : 'None'; ?></label>  
                          <HR  size="3" NOSHADE>
                     <!-- </div> 
                    <div class="col-md-9"> 
                          <p><?php echo  isset($res->CourseYear) ?$res->CourseYear : 'None'; ?></p> ? -->
                          
                    </div> 
                </div> 
            </div>
 


<hr/>
            <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-2"> 
                    <label class="small mb-1" for="DateBorrowed">Date Borrowed</label>  
                    </div> 
                    <div class="col-md-9"> 
                        <p><?php echo  isset($trans->DateBorrowed) ?$trans->DateBorrowed : 'None'; ?></p> 
                    </div> 
                    <div class="col-md-2"> 
                      <label class="small mb-1" for="DueDate">Due Date</label>  
                    </div> 
                    <div class="col-md-9"> 
                        <p><?php echo  isset($trans->DueDate) ?$trans->DueDate : 'None'; ?></p> 
                    </div>       
                </div>      
             </div> 

             
          </div>    



<!-- SELECT `TransactionID`, `IBSN`, `NoCopies`, `DateBorrowed`, `Purpose`, `Status`, `DueDate`, `BorrowerId`, `Borrowed`, `Due`, `Returned`, `DateReturned`, `Remarks` FROM `tbltransaction` WHERE 1 -->

 



<hr/>
  
        <a href="index.php" class="btn btn-success btn-sm"><i class="fa fa-arrow-left"></i> Back</a>  
  </div>
      </div> 
      </div>
  </body>  