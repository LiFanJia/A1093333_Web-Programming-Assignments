<?php
session_start();

 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\Exception;

 require '../../../PHPMailer/src/Exception.php';
 require '../../../PHPMailer/src/PHPMailer.php';
 require '../../../PHPMailer/src/SMTP.php';
 require ('../include/database.php');
 global $mydb;

if (isset($_SESSION['stuID'])){
    $stuID = $_SESSION["stuID"];
}else{

    if (isset($_POST["stuID"])){
        $rStuID = $_POST["stuID"];
    	$mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$rStuID';");
        
        $cur = $mydb->executeQuery();
        if($cur==false){
            die(mysql_error());
        }else{
		    $row_count = $mydb->num_rows($cur);//get the number of count
            if($row_count==1){
            }else{
                echo "<script type = 'text/javascript'>";
                echo "alert('Invalid StudentID!')";
                echo "</script>";
                echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
                exit();
            }
    

        }

        
    }else{
        
        echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
        exit();

    }
    
}

$verifCode = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
		
if (isset($_POST['stuID'])){
    $resetStuID = $_POST['stuID'];
	$mydb->setQuery("UPDATE `tblusers` SET `stuVerifC` = '$verifCode' WHERE  `stuID` = '$resetStuID';");
}else{
	$mydb->setQuery("UPDATE `tblusers` SET `stuVerifC` = '$verifCode' WHERE  `stuID` = '$stuID';");
}

$cur = $mydb->executeQuery();
if($cur==false){
	die(mysql_error());
}
		
    if (isset($_POST["stuID"])){
    	$mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$resetStuID';");
    }else{
    	$mydb->setQuery("SELECT * FROM tblusers WHERE stuID = '$stuID';");
    }

    $cur = $mydb->executeQuery();
    if($cur==false){
        die(mysql_error());
    }
    $row = mysqli_fetch_assoc($cur);
                
    if (isset($_POST['stuID'])){
        $subject = 'OurLibrary - Reset Your Password';
        $message = 'We received a request to reset your account password.<br/>If you didn\'t request this, please ignore this email.<br/>Don\'t worry, your account password won\'t change unless you visit the site and change your password.<br/>
                    <p>Your verification code is: <b style="font-size: 30px;">'.$row['stuVerifC'].'</b></p><br/><br/>
                    Thanks for using the site!';


    }else{
        $subject = 'OurLibrary - Email Verification Code';
        $message = 'Thank you for registering for OurLibrary!<br/>We need to verify your email address to complete your registration process.<br/>
                    <p>Your verification code is: <b style="font-size: 30px;">'.$row['stuVerifC'].'</b></p>';
    }
                
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->SMTPDebug = 0;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'a1093340@mail.nuk.edu.tw';                     //SMTP username
        $mail->Password   = 'Password Here';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;
        $mail->SMTPSecure = 'ssl';                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        $mail->CharSet    = 'UTF-*';
            
            //Recipients
        $mail->setFrom('a1093340@mail.nuk.edu.tw', 'OurLibrary');
            
        $mail->addAddress($row['stuMail']);    
        // $mail->addBCC('a1093340@mail.nuk.edu.tw');
            
        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $message;
        // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();

        if (isset($_POST['stuID'])){
            setcookie("RUID", $resetStuID,time()+50);
            echo "<meta http-equiv='Refresh' content = '0; url=confirmCode.php'>";

            exit();
        }else{
            echo "<meta http-equiv='Refresh' content = '0; url=confirmMail.php'>";
            exit();
        }

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
?>