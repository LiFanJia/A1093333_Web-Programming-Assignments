<?php
require_once("../../include/initialize.php");

if (!isset($_SESSION['stuID'])){
    if ($_SESSION['stuRole'] != "Administrator"){
        echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
        exit();
    }
}


if(isset($_POST['btnBorrow'])){
  $stuid = trim($_POST['stuid']);
  $bookno  = trim($_POST['bookno']);

  $d = date ('Y-m-d', time());
  $due = date ("Y-m-d", strtotime($d. "+1 months"));
  $mydb->setQuery("SELECT stuNo from tblusers WHERE stuID = '$stuid'");

  
  $cur = $mydb->executeQuery();
  if($cur==false){
    //   echo "sql error";
      die(mysql_error());
  }else{
    $row=mysqli_fetch_assoc($cur);
    $stuno = $row['stuNo'];

    $mydb->setQuery("INSERT INTO tbltransaction2 (stuNo, bNo, dueDate, borrowDate, copies) VALUES ($stuno, $bookno, '$due', '$d', 1)");
            
    $cur = $mydb->executeQuery();
    
    if($cur==false){
        die(mysql_error());
    }else{
        $mydb->setQuery("SELECT * FROM tbltransaction2 t, tblusers s, tblbooks b WHERE t.stuNo = s.stuNo AND b.BookID = t.bNo AND t.stuNo = $stuno AND t.bNo = $bookno");
            
        $cur = $mydb->executeQuery();
        if($cur==false){
            die(mysql_error());
        }else{
            $row=mysqli_fetch_assoc($cur);
            $title = $row['BookTitle'];
            $trans = $row['TransID'];
            $no_of_brw = $row['timesBorrowed'];
            if ($no_of_brw == ''){
                $no_of_brw = 0;
            }
            $no_of_brw=$no_of_brw+1;
            $mydb->setQuery("UPDATE tblbooks SET Status = 'Not Available', timesBorrowed = $no_of_brw WHERE BookID = $bookno");
            
            $cur = $mydb->executeQuery();
            if($cur==false){
                die(mysql_error());
            }else{
                echo "<script type = 'text/javascript'>";
                echo "alert('$stuid has successfully completed borrowing \'$title\'')";
                echo "</script>";
                echo "<meta http-equiv='Refresh' content = '0; url=bookinfo.php?id=$trans'>";
            }
        }
    }
  }
}else{
    echo "<script type = 'text/javascript'>";
    echo "alert('Can't complete borrowing!')";
    echo "</script>";
    // echo "<meta http-equiv='Refresh' content = '0; url=addborrow.php'>";

}

 
 ?> 