<?php
require_once("../../include/initialize.php");

if (!isset($_SESSION['stuID']) || !isset($_GET['cid'])){
    echo "<meta http-equiv='Refresh' content = '0; url=borrowinfo.php'>";
    exit();
}

?>


<title>Confirm - OurLibrary</title>


<?php
        global $mydb;
        $cid=$_GET['cid'];

    	$mydb->setQuery("SELECT * FROM tbltransaction2 t, tblusers s, tblbooks b WHERE t.stuNo = s.stuNo AND t.bNo = b.bookID AND TransID = $cid");
                
        $cur = $mydb->executeQuery();
        if($cur==false){
            die(mysql_error());
            echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
            exit();
        }else{
            $row=mysqli_fetch_assoc($cur);
            $bookno = $row['bNo'];

            if ($row['returnDate']==''){
                $d = date ('Y m d', time());
                $xplod = explode(' ', $d);
                // print_r($xplod);
                $dstring = "$xplod[0]-$xplod[1]-$xplod[2]";
                // echo $dstring;
                $d = date ('Y m d', time());

                $date = date("Y-m-d", strtotime($dstring));
                $due = $row['dueDate'];
                $duedate = date("Y-m-d", strtotime($due));
;
                $dateDifference= abs(strtotime($date)-strtotime($due));
                $years = floor ($dateDifference / (365*60*60*24));
                $months = floor (($dateDifference - $years*365*60*60*24)/(30*60*60*24));
                $days = floor(($dateDifference - $years *365 * 60*60*24 - $months *30*60*60*24)/(60*60*24));
                $totdays = ($years*365)+($months*30)+$days;
                // echo $totdays;
                // echo $years." year, ".$months." months and ".$days." days";

                $mydb->setQuery("UPDATE tbltransaction2 SET returnDate = '$date' WHERE TransID = $cid;");

                $cur = $mydb->executeQuery();
                if($cur==false){
                    die(mysql_error());
                    echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";
                    exit();
                }else{
                    
                    $mydb->setQuery("UPDATE tblbooks SET Status = 'Available' WHERE BookID=$bookno;");

                    $cur = $mydb->executeQuery();
                    if($cur==false){
                        die(mysql_error());
                        echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";
                        exit();
                    }else{
                    
                        if ($row['dueDate'] > $date){
                            $fine = 0;
                        }else{
                            $fine = $totdays*10;
                        }

                        $mydb->setQuery("UPDATE tbltransaction2 SET fine = '$fine' WHERE TransID = $cid;");

                        $cur = $mydb->executeQuery();
                        if($cur==false){
                            die(mysql_error());
                            echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";
                            exit();
                        }else{
                            $mydb->setQuery("SELECT * FROM tbltransaction2 WHERE TransID = $cid AND fine = 0;");

                            $cur = $mydb->executeQuery();

                            if($cur==false){
                                die(mysql_error());
                                echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";
                                exit();
                            }else{
                                $row_count = $mydb->num_rows($cur);//get the number of count
                                if ($row_count == 1){
                                    echo "<script type = 'text/javascript'>";
                                    echo "alert ('Return Confirmed! Thanks for returning on time!')";
                                    echo "</script>";
                                    echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";                                
                                }else{
                                    echo "<script type = 'text/javascript'>";
                                    echo "alert ('Return Confirmed! You\'re fined $$fine!')";
                                    echo "</script>";
                                    echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";     
                                }
                            }
                        }
                    }
                }
            }else{
                echo "<script type = 'text/javascript'>";
                echo "alert ('Book had been confirmed!')";
                echo "</script>";
                echo "<meta http-equiv='Refresh' content = '0; url=borrowhis.php?id=$cid'>";
            
            }
        }
      
