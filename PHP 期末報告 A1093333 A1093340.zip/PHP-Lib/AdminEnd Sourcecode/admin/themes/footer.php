<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content=
        "width=device-width, initial-scale=1" />
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  
<style>
.footer {
   position: relative;
   left: 0;
   top:70;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: white;
   text-align: center;

   
        .fa:hover {
            opacity: 0.9;
        }
  
        .fa-facebook {
            background: #007bb5;
            color: white;
        }
  
        .fa-twitter {
            background: #cb2027;
            color: white;
        }
  
        .fa-instagram {
            background: #ff5700;
            color: white;
        }
  
        .fa {
            padding: 20px;
            font-size: 40px;
            width: 60px;
            text-decoration: none;
            margin: 5px 80px;
        }
  
      
}
</style>
</head>
<body>



<div class="footer">
  <p><center>
        <h3>Library Admin System 75862 ©2022</h3>
        <h3>For Questions Regarding the System Contact Administrator A1093340: 坪紋 or Administrator A1093333: 凡佳</h3>
        <a href="tel:123-456-7890"><h4>Call Admin Helpline: 123-456-7890</h4></a>
  
        <!-- Add fonts icons -->
        <a class = "active" href = "/PHP-Lib/login.php">Back to Main Login</a>

    </center>
</p>
</div>

</body>
</html> 
