<?php
// require_once("../../include/initialize.php");
session_start();

if (!isset($_SESSION['stuID']) || !isset($_GET['bid'])){
    echo "<meta http-equiv='Refresh' content = '0; url=login.php'>";
    exit();
}

require("../include/database.php");

$transid = $_GET['bid'];

?>


<title>Rate - OurLibrary</title>

<style>

    body {
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : #EAFFFB;
        height : 100vh;
    }

    
    .center {
        width : 750px;
        background : #fff;
        border-radius : 10px;
        text-align: center;
        position: center;
        margin: auto;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .header {
        overflow: hidden;
        padding: 20px 10px;
    }

    .header a {
        margin : 0 10px;
        background-color: #ffffff;
        float: left;
        color: black;
        text-align: center;
        padding: 12px;
        text-decoration: none;
        font-size: 15px;
        line-height: 0px;
        border-radius: 4px;
    }

    .header a.logoimg {
        margin : -10px 20px;
    }

    .header a.logotxt {
        margin : 8px -20px;
        font-size : 25px;
        font-weight : bold;
    }

    .header a:hover {
        background-color: #ddd;
        color: black;
    }

    .header a.active {
        background-color: #2691d9;
        color: white;
    }

    .header-right {
        float: right;
    }

    @media screen and (max-width: 500px) {
        .header a {
            float: none;
            display: block;
            text-align: left;
        }
        .header-right {
            float: none;
        }
    }
    
    .hero {
    position: relative;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    }

    .hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url(/img/Digital-Library-2048x1494.jpeg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    filter: brightness(60%);
    }

    .hero-content {
    position: relative;
    font-family: "Monserrat", sans-serif;
    color: white;
    text-align: center;
    margin: 0.625rem;
    }

    .hero-title {
    font-size: 3rem;
    font-weight: 600;
    margin-bottom: 0;
    }

    .hero-subtitle {
    font-size: 2rem;
    font-weight: 200;
    margin-top: 1rem;
    }

    .hero-button {
    background-color: #ae2d59;
    color: white;
    border: 1px solid #cb376a;
    margin-top: 5rem;
    padding: 0.9375rem1.875rem;
    font-family: "Monserrat", sans-serif;
    font-size: 1.125rem;
    font-weight: 200;
    cursor: pointer;
    }

    .hero-button:hover {
    background-color: #cb376a;
    border: 1px solid #db7598;
    }

    table, th, td{
        text-align: left;
    }

    th {
        height: 70px;
    }

    td {
        height: 80px;
        /* border:black; border-width:3px; border-style: solid; */
    }

    .titlebook {        
        border:black; 
        border-width:2px; 
        border-style: solid;
    }

    hr{
        width: 100%;
        background-color: black;
        border-color: black;  
    }

    .box{
        margin:20px;
        background-color: white;
    }

</style>

</head>

<body>

<?php
        global $mydb;
    	$mydb->setQuery("SELECT * FROM tbltransaction2 t, tblusers s, tblbooks b WHERE t.bNo = b.BookID AND s.stuNo = t.stuNo AND TransID = '$transid'");
                
        $cur = $mydb->executeQuery();
        if($cur==false){
            die(mysql_error());
        }else{
            $row=mysqli_fetch_assoc($cur);
            $booktit=$row['BookTitle'];            
        }
		
?>

<div class = "box">
    <h2><b>&nbspHow do you rate <?php echo "<h1>'".$booktit."'?</h1>"?></b></h2>
</div>

<br/>

<div class = "box">
    <center><table style = 'font-size : 18; font-family : Helvetica'>
        <form action = '' method = 'POST' enctype = 'multipart/form-data'>
            <input id="trans" name="trans" type="hidden" value="<?php echo $transid?>">
            <TR><TH><u>Rating : </u></TH>
            <TD>&nbsp&nbsp <input type = "number" min = "1" max = "5" name = "rating" id = "rating" required></TD></TR>            
            <TD><input type = 'submit' value = 'Rate!' name='btnRating'></TD>
            
        </form>
        </table>

    </center>


</div>

<br/>

</body>

<?php

if(isset($_POST['btnRating'])){
  $rating = $_POST['rating'];
  $trans = $_POST['trans'];
  $mydb->setQuery("UPDATE tbltransaction2 SET rating = $rating WHERE TransID = $trans");

  
  $cur = $mydb->executeQuery();
  if($cur==false){
    //   echo "sql error";
      die(mysql_error());
  }else{
    echo "<script type = 'text/javascript'>";
    echo "alert ('Thanks for Rating!')";
    echo "</script>";
    echo "<meta http-equiv='Refresh' content = '0; url=mybook.php'>";
    exit();
  }
}else{
    echo "<script type = 'text/javascript'>";
    echo "alert('Can't complete borrowing!')";
    echo "</script>";
    // echo "<meta http-equiv='Refresh' content = '0; url=addborrow.php'>";

}

 
 ?> 