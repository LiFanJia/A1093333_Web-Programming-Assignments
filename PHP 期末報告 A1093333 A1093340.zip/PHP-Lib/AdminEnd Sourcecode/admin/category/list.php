<?php 
	  if (!isset($_SESSION['stuID'])){
      redirect(web_root."admin/index.php");
     } 
?>

<head>

<style>

      body{
        background: #EAFFFB;


    }
	.container{
        border:  ridge;
       width:100%;
	background: #f6e8dc;
	text-align:left;
	font-size:20px;	 
	   padding:7px;
	   font-size:20px;

    }
	.card-header{
        background: rgb(105,105,105,0.7);
        text-align:center;
        font-size:30px;
        border: 5px solid #EAFFFB ;
        padding:  20px;
        border-radius: 16px;
	margin-top:0px;
	margin-bottom:0px;
        
        line-height: 2;
        -webkit-box-decoration-break: clone;
        -o-box-decoration-break: clone;
         box-decoration-break: clone;
    }
	.card-body{
 	text-align:left;
	   margin-right:25px;
	   padding:7px;
	   font-size:20px;
   }

	 .form-group{
     
        width: 30%;
        padding: 12px 20px;
        margin: 8px 0;
        display: block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        
    }

   
</style>

</head>
<body>
<div class="container">  

 <div class="card shadow mb-4">
  <div class="card-header py-3">
    <h3 class="m-0 font-weight-bold text-primary">List of Categories 
    	<?php if ($_SESSION['stuRole']=="SystemAdministrator" || $_SESSION['stuRole']=="Administrator") { ?>
    	<a href="index.php?view=add" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> New</a>
    <?php } ?>
    </h3>
  </div>
  <div class="card-body">
    <div class="table-responsive">  
	 		 <table id="dataTable" class="table table-bordered table-hover"  width="100%" cellspacing="0" style="white-space: nowrap;">
				
				  <thead>
				  	<tr> 
				  		<th> Category</th> 
				  		<th> Dewey Decimal</th> 
				  		 <th >Action</th>
				  	</tr>	
				  </thead> 
				  <tbody>
				  	<?php 
				  		// SELECT `CategoryId`, `Category`, `DDecimal` FROM `tblcategory` WHERE 1
				  		$mydb->setQuery("SELECT * FROM `tblcategory`");
				  		$cur = $mydb->loadResultList();

						foreach ($cur as $result) {
				  		echo '<tr>'; 
				  			echo '<td>' . $result->Category.'</td>';
				  			echo '<td>' . $result->DDecimal.'</td>';

				  		if ($_SESSION['stuRole']=="SystemAdministrator" || $_SESSION['stuRole']=="Administrator") {
				  		echo '<td align="center"><a title="Edit" href="index.php?view=edit&id='.$result->CategoryId.'" class="btn btn-primary btn-sm  ">  <span class="fa fa-edit fw-fa"></span> Edit</a>
				  		     <a title="Delete" href="controller.php?action=delete&id='.$result->CategoryId.'" class="btn btn-danger btn-sm  ">  <span class="fa  fa-trash fw-fa "></span> Delete</a></td>';
				  		 }else{
				  		echo '<td>No Action</td>';

				  		 }
				  		echo '</tr>';
				  	} 
				  	?>
				  </tbody>
					
				</table>  
				</br></br></br></br>

			</div>
		</div>
	</div>
	</div>
  </body>	
	 