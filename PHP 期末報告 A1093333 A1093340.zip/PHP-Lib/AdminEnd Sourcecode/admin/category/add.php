
<?php
     if (!isset($_SESSION['stuID'])){
      redirect(web_root."admin/index.php");
     }

?>

<head>

<style>
 body{
        background: #E0FFFF;


    }
    .container{
        border: double, 3px;
        background: lightgrey;
        /* align:center; */

    }
    .card-header{
        background: rgb(105,105,105,0.7);
        text-align:center;
        font-size:45px;
        border: 5px solid #EAFFFB ;
        padding:  0em 1em;
        border-radius: 16px;
        
        line-height: 2;
        -webkit-box-decoration-break: clone;
        -o-box-decoration-break: clone;
         box-decoration-break: clone;
    }
    .small{
        padding: 12px 20px;
        margin: right;
        text-align-last:left;
        
       

    }

    .col-md-8{
        font-size:30px;
        text-align-last: left;
    }
    .col-md-4{
        font-size:30px;
        text-align-last: right;
        padding: 12px 20px;
        /* margin: 8px 0; */
    }
    .form-group{
     
      
        width: 30%;
        padding: 12px 20px;
        margin: 8px 0;
        display: block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        
        
    }
    .col-md-8{
     
      
     /* width: 30%; */
     padding: 12px 20px;
     /* margin: 8px 0; */
    
     /* border: 1px solid #ccc; */
     border-radius: 4px;
     box-sizing: border-box;
     font-size:25px;
     
     
 }
    



    .form-control{

        width: 90%;
        padding: 12px ;
        /* margin: 8px; */
       
        /* box-sizing: border-box */
        border: 5px;
        font-size:30px;
        text-align:left;
      
       
       
    }
   
    .input-group{ */
        
        width: 50%;
        padding: 12px 20px;
        border: 5px;
        font-size:30px;
        text-align:left;
        float: left;

    }
    .btn{
     
        /* top:20%; */
        background-color:#1E51E5;; 
        font-size:15px;
        padding: 20px;
        margin-left:20px;
        border-radius: 10px;
        border-width: 20px;
        /* font-size: 16px; */
        border:none;
        text-align:center;
    }
    .btn:hover{
       
        color: white;
    }
    </style>

</head>
<body>
<div class="container">  
 <div class="card shadow mb-4">
  <div class="card-header py-3">
    <h2>Add New Category</h2>
  </div>
  <div class="card-body">
    <div class="table-responsive">  
    <form class="form-horizontal span6" action="controller.php?action=add" method="POST" autocomplete="off">
 
 <div class="form-group">
   <div class="col-md-8">
     <label class="col-md-4 control-label" for=
     "CATEGORY">Category:</label>

     <div class="col-md-8">
        <input class="form-control input-sm" id="CATEGORY"  name="CATEGORY" placeholder=
           "Category" type="text" value="">
     </div>
   </div>
 </div>

 <div class="form-group">
   <div class="col-md-8">
     <label class="form-control" for="DDecimal">Dewey Decimal:</label>
     <div class="col-md-8">
        <input class="form-control input-sm" id="DDecimal"  name="DDecimal" placeholder=
           "Dewey Decimal" type="text" value="">

</br></br>
     </div>
   </div>
 </div>


            
             <div class="form-group">
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "idno"></label>

                      <div class="col-md-8">
                      <button class="btn btn-primary" name="save" type="submit" ><span class="fa fa-save fw-fa"></span> Save</button>    <button class="btn btn-primary" name="save" " type="submit" ><span class="fa fa-save fw-fa"></span> Save</button> 
                     
                     </div>
                    </div>
                  </div> 
                  </br></br></br></br>
          
        </form>

      </div>
    </div>
  </div>
      
  </div>
  </body> 