-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 05:47 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumbers`
--

CREATE TABLE `tblautonumbers` (
  `AUTOID` int(11) NOT NULL,
  `AUTOSTART` varchar(30) NOT NULL,
  `AUTOEND` int(11) NOT NULL,
  `AUTOINC` int(11) NOT NULL,
  `AUTOKEY` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblautonumbers`
--

INSERT INTO `tblautonumbers` (`AUTOID`, `AUTOSTART`, `AUTOEND`, `AUTOINC`, `AUTOKEY`) VALUES
(1, '000', 19, 1, 'BorrowerID');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooknumber`
--

CREATE TABLE `tblbooknumber` (
  `ID` int(11) NOT NULL,
  `BOOKTITLE` varchar(255) NOT NULL,
  `QTY` int(11) NOT NULL,
  `Desc` varchar(90) NOT NULL,
  `Author` varchar(90) NOT NULL,
  `PublishDate` date NOT NULL,
  `Publisher` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooknumber`
--

INSERT INTO `tblbooknumber` (`ID`, `BOOKTITLE`, `QTY`, `Desc`, `Author`, `PublishDate`, `Publisher`) VALUES
(5, 'life of juan', 4, 'life of juan', 'unknown', '2016-10-10', 'unknown'),
(6, 'the computerizez system', 2, 'computer', 'unknown', '2016-10-10', 'unknown'),
(7, 'language of us', 2, 'language', 'unknown', '2016-10-10', 'unknown'),
(8, 'science', 2, 'invention of science', 'unknown', '2016-10-10', 'unknown'),
(9, 'book', 4, 'book revised', 'unknown', '2016-10-10', 'unknown'),
(10, 'the only book', 1, 'book', 'unknown', '2016-10-10', 'uknown'),
(11, 'book  now', 2, 'book', 'unknown', '2016-10-10', 'unknown'),
(12, 'the one', 1, 'book1', 'unknown', '2016-10-10', 'unknown'),
(13, 'the life of june', 2, 'journey', 'unknown', '2016-10-10', 'unknown'),
(14, 'title', 1, 'book', 'unknown', '2016-10-10', 'unknown'),
(15, 'sad', 1, 's', 'da', '2018-03-25', 'as'),
(16, '2wqe', 1, 'wqe', 'wqe', '2018-03-25', 'wqe');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE `tblbooks` (
  `BookID` int(11) NOT NULL,
  `IBSN` varchar(13) NOT NULL,
  `BookTitle` varchar(125) NOT NULL,
  `BookDesc` text NOT NULL,
  `Author` varchar(125) NOT NULL,
  `PublishDate` date NOT NULL,
  `BookPublisher` varchar(125) NOT NULL,
  `Category` varchar(90) NOT NULL,
  `BookPrice` double NOT NULL,
  `BookQuantity` int(11) NOT NULL,
  `Status` varchar(30) NOT NULL,
  `BookType` varchar(90) NOT NULL,
  `imgPath` text DEFAULT NULL,
  `imgDate` int(10) DEFAULT NULL,
  `DeweyDecimal` varchar(90) NOT NULL,
  `OverAllQty` int(11) NOT NULL,
  `Donate` tinyint(1) NOT NULL,
  `Remarks` varchar(90) NOT NULL,
  `timesBorrowed` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`BookID`, `IBSN`, `BookTitle`, `BookDesc`, `Author`, `PublishDate`, `BookPublisher`, `Category`, `BookPrice`, `BookQuantity`, `Status`, `BookType`, `imgPath`, `imgDate`, `DeweyDecimal`, `OverAllQty`, `Donate`, `Remarks`, `timesBorrowed`) VALUES
(1, '12345678', 'Harry Potter and the Philosopher\'s Stone', 'Celebrate 20 years of Harry Potter magic! Harry Potter has never even heard of Hogwarts when the letters start dropping on the doormat at number four, Privet Drive. Addressed in green ink on yellowish parchment with a purple seal, they are swiftly confiscated by his grisly aunt and uncle. Then, on Harry\'s eleventh birthday, a great beetle-eyed giant of a man called Rubeus Hagrid bursts in with some astonishing news: Harry Potter is a wizard, and he has a place at Hogwarts School of Witchcraft and Wizardry. An incredible adventure is about to begin!These new editions of the classic and internationally bestselling, multi-award-winning series feature instantly pick-up-able new jackets by Jonny Duddle, with huge child appeal, to bring Harry Potter to the next generation of readers. It\'s time to PASS THE MAGIC ON ...\r\n', 'J. K. Rowling', '2014-09-01', 'Bloomsbury Publishing', 'History and Geography', 175, 1, 'Available', 'Fiction', 'Photo_1654704469.jpg', 1654704469, '900', 1, 0, 'Donate', 3),
(2, '12345671', 'Milestones of Science and Technology: Making the Modern World', 'The Kodak camera, the CT scanner, the steam turbine, the telephone--such inventions not only changed the course of history, but also changed our understanding of what the human race could achieve. An authoritative guide to the remarkable history of human innovation, this second edition, published in collaboration with London’s Science Museum, brings readers up to date with insightful examinations of the new, present-day technologies society already takes for granted--from magnetic resonance imaging to the Internet. Organized chronologically, the book begins with a look at scientific achievement in the early Middle Ages and the navigational tools that mapped the New World before moving on to the steam-powered machines of the Industrial Revolution, the lifesaving medicines of World Wars I and II, and the dynamically designed consumer goods of the 1950s and 1960s. An essay about each invention, written by an expert from London’s Science Museum, includes a short history of the invention’s creation, use, and significance.', 'Peter Morris', '2013-07-22', 'KWS Publishers', 'Technology', 200, 1, 'Not Available', 'Non-Fiction', 'Photo_1654705808.jpg', 1654705808, '100', 1, 0, 'Donate', 1),
(3, '12345672', 'Easy French Step-By-Step: Master High-Frequency Grammar ', 'Easy French Step-by-Step proves that a solid grounding in grammar basics is the key to mastering a second language. You are quickly introduced to grammatical rules and concepts in order of importance, which you can build on as you progress through the book. You will also learn more than 300 verbs, chosen by their frequency of use. Numerous exercises and engaging readings help you quickly build your speaking and comprehension prowess.', 'Myrna Bell Rochester', '2008-11-01', 'McGraw-Hill Education', 'Language', 180, 1, 'Not Available', 'Non-Fiction', 'Photo_1654705862.jpg', 1654705862, '400', 1, 0, 'Purchased', NULL),
(6, '1345673', 'The Guns of August', 'Selected by the Modern Library as one of the 100 best nonfiction books of all timeIn this landmark account, renowned historian Barbara W. Tuchman re-creates the first month of World War I: thirty days in the summer of 1914 that determined the course of the conflict, the century, and ultimately our present world. Beginning with the funeral of Edward VII, Tuchman traces each step that led to the inevitable clash. And inevitable it was, with all sides plotting their war for a generation. Dizzyingly comprehensive and spectacularly portrayed with her famous talent for evoking the characters of the war’s key players, Tuchman’s magnum opus is a classic for the ages.The Proud Tower, the Pulitzer Prize-winning The Guns of August, and The Zimmermann Telegram comprise Barbara W. Tuchman’s classic histories of the First World War era', 'Barbara W. Tuchman', '2004-08-03', 'Presidio Press', 'History and Geography', 185, 1, 'Available', 'Fiction', 'Photo_1654705895.jpg', 1654705895, '900', 1, 0, 'Purchased', 1),
(7, '14256372', 'Steven Caney\'s Invention Book', 'Kids are natural inventors, bursting with notions so crazy they just might work. Chester Greenwood was just a boy when his big cold ears prompted him to fashion wire and fur into the world\'s first earmuffs. Caney shows how to get into ', 'Steven Caney', '1985-01-06', 'Workman Publishing Company', 'Science', 185, 1, 'Available', 'Non-Fiction', 'Photo_1654705926.jpg', 1654705926, '500', 1, 0, 'Purchased', NULL),
(8, '15243678', 'Life 3.0: Being Human in the Age of Artificial Intelligence', 'New York Times Best SellerHow will Artificial Intelligence affect crime, war, justice, jobs, society and our very sense of being human? The rise of AI has the potential to transform our future more than any other technology—and there’s nobody better qualified or situated to explore that future than Max Tegmark, an MIT professor who’s helped mainstream research on how to keep AI beneficial. How can we grow our prosperity through automation without leaving people lacking income or purpose? What career advice should we give today’s kids? How can we make future AI systems more robust, so that they do what we want without crashing, malfunctioning or getting hacked? Should we fear an arms race in lethal autonomous weapons? Will machines eventually outsmart us at all tasks, replacing humans on the job market and perhaps altogether? Will AI help life flourish like never before or give us more power than we can handle? What sort of future do you want? This book empowers you to join what may be the most important conversation of our time. It doesn’t shy away from the full range of viewpoints or from the most controversial issues—from superintelligence to meaning, consciousness and the ultimate physical limits on life in the cosmos.', 'Max Tegmark', '2017-08-29', 'Deckle Edge', 'Technology', 109, 1, 'Available', 'Fiction', 'Photo_1654705955.jpg', 1654705955, '600', 1, 0, 'Purchased', 3),
(9, '15263712', 'Japanese from Zero! 1: Proven Techniques to Learn Japanese for Students and Professionals', 'languageJapanese From Zero! is an innovative and integrated approach to learning Japanese developed by professional Japanese interpreter George Trombley and co-writer Yukari Takenaka.The lessons and techniques used in this series have been taught successfully for over ten years in classrooms throughout the world.Using up-to-date and easy-to-grasp grammar, Japanese From Zero! is the perfect course for current students of Japanese as well as absolute beginners.In Book 1 of the Japanese From Zero! series, readers are taught new grammar concepts, over 800 new words and expressions, and also learn the hiragana writing system.', 'Yukari Takenaka', '2006-05-01', 'Yesjapan Corporation', 'Language', 400, 1, 'Not Available', 'Non-Fiction', 'Photo_1654705976.jpg', 1654705976, '400', 1, 0, 'Donate', 2),
(10, '19872634', 'The Circle', 'The Circle is the exhilarating new novel from Dave Eggers, best-selling author of A Hologram for the King, a finalist for the National Book Award.When Mae Holland is hired to work for the Circle, the world\'s most powerful internet company, she feels she\'s been given the opportunity of a lifetime. The Circle, run out of a sprawling California campus, links users\' personal emails, social media, banking, and purchasing with their universal operating system, resulting in one online identity and a new age of civility and transparency. As Mae tours the open-plan office spaces, the towering glass dining facilities, the cozy dorms for those who spend nights at work, she is thrilled with the company\'s modernity and activity. There are parties that last through the night, there are famous musicians playing on the lawn, there are athletic activities and clubs and brunches, and even an aquarium of rare fish retrieved from the Marianas Trench by the CEO. Mae can\'t believe her luck, her great fortune to work for the most influential company in the world--even as life beyond the campus grows distant, even as a strange encounter with a colleague leaves her shaken, even as her role at the Circle becomes increasingly public. What begins as the captivating story of one woman\'s ambition and idealism soon becomes a heart-racing novel of suspense, raising questions about memory, history, privacy, democracy, and the limits of human knowledge.', 'Dave Eggers', '2015-12-15', 'Knopf', 'Technology', 190, 1, 'Available', 'Fiction', 'Photo_1654706003.jpg', 1654706003, '600', 1, 0, 'Purchased', 2),
(11, '18293746', 'Before Music: Where Instruments Come From', 'Music doesn’t come out of nothing.It always starts somewhere . . . with something . . . with someone. Discover how music is made in this survey of musical instruments from around the world. Organized by material—from wood to gourds to found objects and more—Before Music marries a lyrical core text with tons of informational material for curious readers.In the narrative text, readers will encounter makers as they source their materials and craft instruments by hand, drawing the line from the natural world to the finished product and its sound. The sidebars offer much more to discover, including extensive instrument lists, short bios of musical innovators, and more.', 'Annette Bay Pimentel', '2022-06-21', 'Abrams Books for Young Readers', 'Arts and Recreation', 120, 1, 'Available', 'Fiction', 'Photo_1654706030.jpg', 1654706030, '700', 1, 0, 'Donate', 1),
(12, '11726354', 'After the Rain', 'After the Rain is a graphic novel adaptation of Nnedi Okorafor’s short story “On the Road.” The drama takes place in a small Nigerian town during a violent and unexpected storm. A Nigerian-American woman named Chioma answers a knock at her door and is horrified to see a boy with a severe head wound standing at her doorstep. He reaches for her, and his touch burns like fire. Something is very wrong. Haunted and hunted, Chioma must embrace her heritage in order to survive. John Jennings and David Brame’s graphic novel collaboration uses bold art and colors to powerfully tell this tale of identity and destiny.', 'Nnedi Okorafor', '2021-01-05', 'Abrams ComicArts', 'Arts and Recreation', 100, 1, 'Not Available', 'Fiction', 'Photo_1654744655.jpg', 1654744655, '700', 1, 0, 'Purchased', 4),
(13, '10928273', 'Quantitative Social Science: An Introduction', 'Quantitative analysis is an increasingly essential skill for social science research, yet students in the social sciences and related areas typically receive little training in it--or if they do, they usually end up in statistics classes that offer few insights into their field. This textbook is a practical introduction to data analysis and statistics written especially for undergraduates and beginning graduate students in the social sciences and allied fields, such as economics, sociology, public policy, and data science.Quantitative Social Science engages directly with empirical analysis, showing students how to analyze data using the R programming language and to interpret the results--it encourages hands-on learning, not paper-and-pencil statistics. More than forty data sets taken directly from leading quantitative social science research illustrate how data analysis can be used to answer important questions about society and human behavior.Proven in the classroom, this one-of-a-kind textbook features numerous additional data analysis exercises and interactive R programming exercises, and also comes with supplementary teaching materials for instructors.Written especially for students in the social sciences and allied fields, including economics, sociology, public policy, and data scienceProvides hands-on instruction using R programming, not paper-and-pencil statisticsIncludes more than forty data sets from actual research for students to test their skills onCovers data analysis concepts such as causality, measurement, and prediction, as well as probability and statistical toolsFeatures a wealth of supplementary exercises, including additional data analysis exercises and interactive programming exercisesOffers a solid foundation for further studyComes with additional course materials online, including notes, sample code, exercises and problem sets with solutions, and lecture slides', 'Imai, Kosuke', '2018-02-09', 'Princeton University Press', 'Social Science', 212, 1, 'Not Available', 'Non-Fiction', 'Photo_1654706101.webp', 1654706101, '300', 1, 0, 'Purchased', 2),
(14, '10987654', 'Digital Minimalism: Choosing a Focused Life in a Noisy World', '', 'Cal Newport', '2019-02-05', 'Portfolio', 'Technology', 220, 1, 'Available', 'Non-Fiction', 'Photo_1654738922.jpg', 1654738922, '600', 1, 0, 'Purchased', NULL),
(15, '98172634', 'Breath: The New Science of a Lost Art ', 'There is nothing more essential to our health and well-being than breathing: take air in, let it out, repeat twenty-five thousand times a day. Yet, as a species, humans have lost the ability to breathe correctly, with grave consequences.Journalist James Nestor travels the world to figure out what went wrong and how to fix it. The answers aren’t found in pulmonology labs, as we might expect, but in the muddy digs of ancient burial sites, secret Soviet facilities, New Jersey choir schools, and the smoggy streets of São Paulo. Nestor tracks down men and women exploring the hidden science behind ancient breathing practices like Pranayama, Sudarshan Kriya, and Tummo and teams up with pulmonary tinkerers to scientifically test long-held beliefs about how we breathe.Modern research is showing us that making even slight adjustments to the way we inhale and exhale can jump-start athletic performance; rejuvenate internal organs; halt snoring, asthma, and autoimmune disease; and even straighten scoliotic spines. None of this should be possible, and yet it is.Drawing on thousands of years of medical texts and recent cutting-edge studies in pulmonology, psychology, biochemistry, and human physiology, Breath turns the conventional wisdom of what we thought we knew about our most basic biological function on its head. You will never breathe the same again.', 'James Nestor', '2020-05-26', 'Riverhead Books', 'Science', 100, 1, 'Not Available', 'Fiction', 'Photo_1654706164.jpg', 1654706164, '500', 1, 0, 'Donate', 2),
(16, '19282736', 'Snow Crash: A Novel', 'In reality, Hiro Protagonist delivers pizza for Uncle Enzo’s CosoNostra Pizza Inc., but in the Metaverse he’s a warrior prince. Plunging headlong into the enigma of a new computer virus that’s striking down hackers everywhere, he races along the neon-lit streets on a search-and-destroy mission for the shadowy virtual villain threatening to bring about infocalypse. Snow Crash is a mind-altering romp through a future America so bizarre, so outrageous . . . you’ll recognize it immediately.', 'Neal Stephenson', '1992-06-10', 'Bantam Books', 'Science', 100, 1, 'Available', 'Non-Fiction', 'Photo_1654706214.jpg', 1654706214, '500', 1, 0, 'Purchased', NULL),
(17, '9812345', 'Words and Rules: The Ingredients Of Language (Science Masters Series)', '', 'Steven Pinker', '1999-01-01', 'Basic Books', 'Language', 90, 1, 'Available', 'Fiction', 'Photo_1654706239.jpg', 1654706239, '400', 1, 0, 'Purchased', 1),
(18, '12345670', 'Computer Systems: Digital Design, Fundamentals of Computer Architecture and Assembly Language', 'This textbook covers digital design, fundamentals of computer architecture, and assembly language. The book starts by introducing basic number systems, character coding, basic knowledge in digital design, and components of a computer. The book goes on to discuss information representation in computing; Boolean algebra and logic gates; sequential logic; input/output; and CPU performance. The author also covers ARM architecture, ARM instructions and ARM assembly language which is used in a variety of devices such as cell phones, digital TV, automobiles, routers, and switches. The book contains a set of laboratory experiments related to digital design using Logisim software; in addition, each chapter features objectives, summaries, key terms, review questions and problems. The book is targeted to students majoring Computer Science, Information System and IT and follows the ACM/IEEE 2013 guidelines.', 'Ata Elahi', '2018-08-25', 'Springer', 'Computers, Information and General Reference', 200, 1, 'Available', 'Non-Fiction', 'Photo_1654706261.jpg', 1654706261, '000', 1, 0, 'Purchased', NULL),
(19, '12345677', 'The Silk Roads: A New History of the World', 'Far more than a history of the Silk Roads, this book is truly a revelatory new history of the world, promising to destabilize notions of where we come from and where we are headed next. From the Middle East and its political instability to China and its economic rise, the vast region stretching eastward from the Balkans across the steppe and South Asia has been thrust into the global spotlight in recent years. Frankopan teaches us that to understand what is at stake for the cities and nations built on these intricate trade routes, we must first understand their astounding pasts. Frankopan realigns our understanding of the world, pointing us eastward. It was on the Silk Roads that East and West first encountered each other through trade and conquest, leading to the spread of ideas, cultures and religions. From the rise and fall of empires to the spread of Buddhism and the advent of Christianity and Islam, right up to the great wars of the twentieth century—this book shows how the fate of the West has always been inextricably linked to the East.', 'Peter Frankopan', '2017-03-07', 'Vintange', 'History and Geography', 900, 1, 'Available', 'Fiction', 'Photo_1654706291.jpg', 1654706291, '900', 1, 0, 'Donate', NULL),
(21, '9876547', 'Digital Fortress: A Thriller', 'When the NSA\'s invincible code-breaking machine encounters a mysterious code it cannot break, the agency calls its head cryptographer, Susan Fletcher, a brilliant and beautiful mathematician. What she uncovers sends shock waves through the corridors of power. The NSA is being held hostage...not by guns or bombs, but by a code so ingeniously complex that if released it would cripple U.S. intelligence.Caught in an accelerating tempest of secrecy and lies, Susan Fletcher battles to save the agency she believes in. Betrayed on all sides, she finds herself fighting not only for her country but for her life, and in the end, for the life of the man she loves.From the underground hallways of power to the skyscrapers of Tokyo to the towering cathedrals of Spain, a desperate race unfolds. It is a battle for survival--a crucial bid to destroy a creation of inconceivable genius...an impregnable code-writing formula that threatens to obliterate the post-cold war balance of power. Forever.', 'Dan Brown', '1998-10-08', 'St. Martin\'s Press', 'Technology', 370, 1, 'Available', 'Fiction', 'Photo_1654706318.jpg', 1654706318, '600', 1, 0, 'Purchased', NULL),
(23, '117263548', 'Knowledge Genius!: A Quiz Encyclopedia to Boost Your Brain ', 'A brilliant quiz book for clever kids - put your general knowledge to the test and boggle your family and friends with your brainpowerCan you name the longest river in Europe? Do you know your skull from your sternum? Can you identify an archaeopteryx and an allosaurus? Can you recognise the flags of India and Italy?You canThen what are you waiting for? Open the pages of Knowledge Genius to find out what you know, and challenge yourself to learn even moreWith more than 60 topics, from across the encyclopedia, there\'s something for everyone. The pages are packed with eye-popping pictures - but do you know what they show? To help you, Test Yourself panels list what you\'re looking for. With three levels of difficulty, the challenge gets harder as you work your way from Starter, to Challenger, and finally the truly tricky Genius category. If you need it, there\'s a fun fact with every picture to give a helpful clue.Take on the Knowledge Genius brain-busting challenge', 'DK', '2019-04-16', 'DK Publishing', 'ALL', 23, 1, 'Available', '', 'Photo_1654706345.jpg', 1654706345, '', 1, 0, 'Purchased', NULL),
(24, '23124243', 'The Christmas Pig', 'A heartwarming, page-turning adventure about one child\'s love for his most treasured thing.', 'J. K. Rowling', '2021-10-12', 'SCHOLASTIC INC.', 'Literature', 499, 1, 'Available', '', 'Photo_1654706399.jpg', 1654706399, '800', 1, 0, 'Purchased', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblborrower`
--

CREATE TABLE `tblborrower` (
  `IDNO` int(11) NOT NULL,
  `BorrowerId` varchar(90) NOT NULL,
  `Firstname` varchar(125) NOT NULL,
  `Lastname` varchar(125) NOT NULL,
  `MiddleName` varchar(125) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Sex` varchar(11) NOT NULL,
  `ContactNo` varchar(125) NOT NULL,
  `CourseYear` varchar(125) NOT NULL,
  `BorrowerPhoto` varchar(255) NOT NULL,
  `BorrowerType` varchar(35) NOT NULL,
  `Stats` varchar(36) NOT NULL,
  `BUsername` varchar(90) NOT NULL,
  `BPassword` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblborrower`
--

INSERT INTO `tblborrower` (`IDNO`, `BorrowerId`, `Firstname`, `Lastname`, `MiddleName`, `Address`, `Sex`, `ContactNo`, `CourseYear`, `BorrowerPhoto`, `BorrowerType`, `Stats`, `BUsername`, `BPassword`) VALUES
(1, '119', 'jom', 'lozada', 'baron', 'ilog', 'Female', '0920', 'BEED', 'photos/02052020123045077db70b-ab84-46c4-bbaa-a5dd6b7332a4_200x200.png', 'Students', 'Active', 'jom', ''),
(2, '213', 'Janno', 'Palacios', 'E', 'kabankalan City', 'Male', '0192836383', 'BSIT-2', 'Chrysanthemum.jpg', 'Student', 'Active', '', ''),
(3, '912', 'lou', 'gotera', 'velez', 'rizal', 'Female', '0930', 'BSIT', 'bhl-logo.jpg', 'Student', 'Active', '', ''),
(4, '921', 'joma', 'baron', 'lozada', 'dancalan', 'Female', '0921', '', 'Desert.jpg', 'Student', '', '', ''),
(5, '1234', 'ambot', 'sure', 'guess', 'unknown', 'Male', '0907', 'ELECTRONICS', 'Koala.jpg', 'Student', 'NotActive', '', ''),
(6, '4321', 'John Craig', 'Nillos', 'Palacios', 'Dancalan Ilog', 'Male', '1233213123', 'BSIT-1', 'Wonderful-Room-King.jpg', 'Student', 'Active', '', ''),
(7, '9213', 'lou', 'velez', 'gotera', 'rizal', 'Female', '0930', 'BSIT', 'Lighthouse.jpg', 'Student', 'NotActive', '', ''),
(8, '54321', 'virgel', 'tem', 'brevilla', 'unknown', 'Female', '0930', 'BEED', 'ARIEL 6.jpg', 'Student', 'Active', '', ''),
(9, '123432', 'Mark', 'Palacios', 'E', 'Galicia Ilog', 'Male', '09291918272', 'HRM-1', 'Chrysanthemum.jpg', 'Student', 'Active', '', ''),
(22, '202000015', 'sad', 'sad', 'sad', 'asd', 'Female', 'asd', '213', 'photos/', 'Students', 'Active', 'asd', 'f10e2821bbbea527ea02200352313bc059445190'),
(23, '202000016', 'Jean', 'Sy', 'Ong', 'Philippines', 'Female', '0923564521', 'AB-English', 'photos/04052020042948110218.jpg', 'Students', 'Active', 'Jean', '8c34f90c4d920b3126a0a0bf4aecf2a820fce8a7'),
(25, '202200018', 'Frankie', 'Francis', 'Gelanny', 'Candyland', 'Female', '9864356754', 'Bsti-2022', 'borrower/15052022101301COFFEE.jpg', 'Students', 'Active', 'frankaphone', 'dc724af18fbdd4e59189f5fe768a5f8311527050');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CategoryId` int(11) NOT NULL,
  `Category` varchar(125) NOT NULL,
  `DDecimal` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CategoryId`, `Category`, `DDecimal`) VALUES
(1, 'Computers, Information and General Reference', '001'),
(2, 'Philosophy and Psychology', '100'),
(3, 'Religion', '200'),
(4, 'Social Science', '300'),
(5, 'Language', '400'),
(6, 'Science', '500'),
(7, 'Technology', '600'),
(8, 'Arts and Recreation', '700'),
(9, 'Literature', '800'),
(10, 'History and Geography', '900'),
(12, 'ALL', 'ALL'),
(13, 'Romance', '345789');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogs`
--

CREATE TABLE `tbllogs` (
  `LogId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `LogDate` datetime NOT NULL,
  `LogMode` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbllogs`
--

INSERT INTO `tbllogs` (`LogId`, `UserId`, `LogDate`, `LogMode`) VALUES
(1, 3, '2016-08-22 14:30:29', 'Logged in'),
(2, 3, '2016-08-22 14:38:37', 'Logged in'),
(3, 3, '2016-08-22 14:39:03', 'Logged out'),
(4, 3, '2016-08-22 14:47:10', 'Logged in'),
(5, 3, '2016-08-22 14:48:08', 'Logged in'),
(6, 3, '2016-08-22 14:49:32', 'Logged in'),
(7, 3, '2016-08-22 14:57:43', 'Logged in'),
(8, 3, '2016-08-22 14:59:12', 'Logged in'),
(9, 3, '2016-08-22 15:05:27', 'Logged in'),
(10, 3, '2016-08-22 15:23:37', 'Logged in'),
(11, 3, '2016-08-22 15:23:47', 'Logged out'),
(12, 3, '2016-08-22 15:25:00', 'Logged in'),
(13, 3, '2016-08-22 15:25:32', 'Logged out'),
(14, 3, '2016-08-22 15:26:38', 'Logged in'),
(15, 3, '2016-08-22 15:26:45', 'Logged out'),
(16, 3, '2016-08-22 15:27:30', 'Logged in'),
(17, 3, '2016-08-22 15:27:57', 'Logged out'),
(18, 3, '2016-08-22 15:30:28', 'Logged in'),
(19, 3, '2016-08-22 15:31:16', 'Logged out'),
(20, 3, '2016-08-22 15:32:22', 'Logged in'),
(21, 3, '2016-08-22 15:32:54', 'Logged out'),
(22, 3, '2016-08-22 15:34:20', 'Logged in'),
(23, 3, '2016-08-22 15:35:06', 'Logged out'),
(24, 3, '2016-08-22 15:58:47', 'Logged in'),
(25, 3, '2016-08-22 16:02:41', 'Logged out'),
(26, 7, '2016-08-22 16:06:52', 'Logged in'),
(27, 7, '2016-08-24 16:33:38', 'Logged out'),
(28, 3, '2016-08-24 16:33:49', 'Logged in'),
(29, 3, '2016-08-24 16:37:57', 'Logged out'),
(30, 8, '2016-08-24 16:38:08', 'Logged in'),
(31, 8, '2016-08-24 16:40:07', 'Logged out'),
(32, 3, '2016-08-24 16:40:16', 'Logged in'),
(33, 3, '2016-08-24 16:46:31', 'Logged out'),
(34, 3, '2016-08-24 16:48:08', 'Logged in'),
(35, 8, '2016-08-24 16:55:05', 'Logged in'),
(36, 8, '2016-08-24 16:55:11', 'Logged out'),
(37, 8, '2016-08-24 16:55:49', 'Logged in'),
(38, 8, '2016-08-24 17:11:26', 'Logged out'),
(39, 4, '2016-08-24 19:09:55', 'Logged in'),
(40, 3, '2016-08-24 19:18:02', 'Logged in'),
(41, 3, '2016-08-24 19:23:46', 'Logged in'),
(42, 3, '2016-08-24 19:26:44', 'Logged in'),
(43, 3, '2016-08-22 19:28:32', 'Logged out'),
(44, 3, '2016-08-22 19:29:28', 'Logged in'),
(45, 3, '2016-08-22 19:49:21', 'Logged out'),
(46, 3, '2016-08-22 19:52:51', 'Logged in'),
(47, 3, '2016-08-22 19:54:52', 'Logged out'),
(48, 3, '2016-08-22 20:00:32', 'Logged in'),
(49, 3, '2016-08-22 20:01:40', 'Logged out'),
(50, 3, '2016-08-22 20:02:54', 'Logged in'),
(51, 3, '2016-08-22 20:04:21', 'Logged out'),
(52, 3, '2016-08-22 20:06:14', 'Logged in'),
(53, 3, '2016-08-22 20:06:42', 'Logged out'),
(54, 3, '2016-08-22 20:47:41', 'Logged in'),
(55, 3, '2016-08-22 20:48:31', 'Logged out'),
(56, 3, '2016-08-22 20:49:21', 'Logged in'),
(57, 3, '2016-08-22 20:50:50', 'Logged out'),
(58, 3, '2016-08-22 21:00:01', 'Logged in'),
(59, 3, '2016-08-22 21:00:28', 'Logged out'),
(60, 3, '2016-08-22 21:08:06', 'Logged in'),
(61, 3, '2016-08-22 21:08:53', 'Logged out'),
(62, 3, '2016-08-22 21:10:56', 'Logged in'),
(63, 3, '2016-08-22 21:11:26', 'Logged in'),
(64, 3, '2016-08-22 21:12:52', 'Logged out'),
(65, 3, '2016-08-22 21:15:07', 'Logged in'),
(66, 3, '2016-08-22 21:20:13', 'Logged out'),
(67, 3, '2016-08-22 21:23:59', 'Logged in'),
(68, 3, '2016-08-22 22:06:06', 'Logged in'),
(69, 3, '2016-08-22 22:30:16', 'Logged out'),
(70, 3, '2016-08-24 10:23:30', 'Logged in'),
(71, 3, '2016-08-24 10:25:30', 'Logged out'),
(72, 3, '2016-08-24 10:34:54', 'Logged in'),
(73, 3, '2016-08-24 10:51:46', 'Logged out'),
(74, 3, '2016-08-24 12:59:04', 'Logged in'),
(75, 3, '2016-08-24 13:11:17', 'Logged out'),
(76, 3, '2016-08-24 13:15:06', 'Logged in'),
(77, 3, '2016-08-24 13:38:36', 'Logged out'),
(78, 9, '2016-08-24 13:39:02', 'Logged in'),
(79, 9, '2016-08-24 13:41:12', 'Logged out'),
(80, 3, '2016-08-24 13:42:56', 'Logged in'),
(81, 3, '2016-08-24 13:44:20', 'Logged out'),
(82, 3, '2016-08-25 10:22:43', 'Logged in'),
(83, 3, '2016-08-25 10:23:12', 'Logged out'),
(84, 3, '2016-08-30 14:16:22', 'Logged in'),
(85, 3, '2016-08-30 14:16:48', 'Logged out'),
(86, 3, '2016-08-30 14:18:20', 'Logged in'),
(87, 3, '2016-08-30 14:19:12', 'Logged out'),
(88, 3, '2016-08-30 14:22:55', 'Logged in'),
(89, 3, '2016-08-30 14:24:26', 'Logged out'),
(90, 3, '2016-08-30 14:25:22', 'Logged in'),
(91, 3, '2016-08-30 14:26:11', 'Logged out'),
(92, 3, '2016-08-30 14:36:08', 'Logged in'),
(93, 3, '2016-08-30 14:36:32', 'Logged out'),
(94, 3, '2016-08-30 14:38:16', 'Logged in'),
(95, 3, '2016-08-30 14:38:45', 'Logged out'),
(96, 3, '2016-08-30 14:40:48', 'Logged in'),
(97, 3, '2016-08-30 14:43:06', 'Logged out'),
(98, 3, '2016-08-30 14:46:35', 'Logged in'),
(99, 3, '2016-08-30 14:48:53', 'Logged in'),
(100, 3, '2016-08-30 14:49:48', 'Logged out'),
(101, 3, '2016-08-30 14:51:34', 'Logged in'),
(102, 3, '2016-08-30 14:51:54', 'Logged out'),
(103, 3, '2016-08-30 14:52:33', 'Logged in'),
(104, 3, '2016-08-30 14:54:24', 'Logged out'),
(105, 3, '2016-08-30 14:58:10', 'Logged in'),
(106, 3, '2016-08-30 15:05:33', 'Logged out'),
(107, 3, '2016-08-30 15:09:54', 'Logged in'),
(108, 3, '2016-08-30 15:14:43', 'Logged out'),
(109, 3, '2016-08-30 15:15:41', 'Logged in'),
(110, 3, '2016-08-30 15:17:55', 'Logged out'),
(111, 3, '2016-08-30 15:27:54', 'Logged in'),
(112, 3, '2016-08-30 15:29:59', 'Logged out'),
(113, 3, '2016-08-30 15:30:32', 'Logged in'),
(114, 3, '2016-08-30 15:32:17', 'Logged out'),
(115, 3, '2016-09-01 10:46:31', 'Logged in'),
(116, 3, '2016-09-01 11:13:31', 'Logged in'),
(117, 3, '2016-08-30 11:36:16', 'Logged out'),
(118, 3, '2016-09-01 11:40:35', 'Logged in'),
(119, 3, '2016-09-01 11:55:36', 'Logged out'),
(120, 9, '2016-09-01 11:55:59', 'Logged in'),
(121, 9, '2016-09-01 12:00:28', 'Logged out'),
(122, 3, '2016-09-01 12:00:37', 'Logged in'),
(123, 3, '2016-09-01 12:09:16', 'Logged in'),
(124, 3, '2016-09-01 12:09:34', 'Logged out'),
(125, 9, '2016-09-01 12:09:44', 'Logged in'),
(126, 9, '2016-09-01 12:17:04', 'Logged out'),
(127, 3, '2016-09-01 12:17:38', 'Logged out'),
(128, 3, '2016-09-01 12:28:49', 'Logged in'),
(129, 3, '2016-09-01 12:29:27', 'Logged in'),
(130, 3, '2016-09-01 12:36:20', 'Logged out'),
(131, 9, '2016-09-01 12:37:10', 'Logged in'),
(132, 9, '2016-09-01 12:38:48', 'Logged out'),
(133, 3, '2016-09-01 12:39:49', 'Logged in'),
(134, 3, '2016-09-01 12:40:18', 'Logged out'),
(135, 3, '2016-09-01 12:40:49', 'Logged in'),
(136, 3, '2016-09-01 12:44:13', 'Logged out'),
(137, 3, '2016-09-01 12:45:35', 'Logged out'),
(138, 3, '2016-09-01 13:29:56', 'Logged in'),
(139, 3, '2016-09-01 13:30:25', 'Logged out'),
(140, 3, '2016-09-01 14:23:41', 'Logged in'),
(141, 3, '2016-09-01 16:02:46', 'Logged out'),
(142, 3, '2016-09-01 16:32:46', 'Logged in'),
(143, 9, '2016-09-01 16:55:59', 'Logged in'),
(144, 3, '2016-09-01 17:14:17', 'Logged out'),
(145, 3, '2016-09-01 17:26:45', 'Logged in'),
(146, 3, '2016-09-01 17:43:03', 'Logged out'),
(147, 9, '2016-09-01 18:04:33', 'Logged in'),
(148, 9, '2016-09-01 18:06:00', 'Logged out'),
(149, 3, '2016-09-01 18:12:26', 'Logged in'),
(150, 3, '2016-09-01 18:13:08', 'Logged out'),
(151, 3, '2016-09-02 00:03:45', 'Logged in'),
(152, 9, '2016-09-02 00:04:34', 'Logged in'),
(153, 9, '2016-09-02 00:05:36', 'Logged out'),
(154, 3, '2016-09-02 00:05:50', 'Logged in'),
(155, 3, '2016-09-02 00:06:17', 'Logged out'),
(156, 3, '2016-09-02 00:06:27', 'Logged out'),
(157, 3, '2016-09-02 00:50:25', 'Logged in'),
(158, 3, '2016-09-02 01:00:34', 'Logged out'),
(159, 3, '2016-09-02 09:02:56', 'Logged in'),
(160, 3, '2016-09-02 09:06:24', 'Logged out'),
(161, 3, '2016-09-02 09:23:28', 'Logged in'),
(162, 3, '2016-09-02 09:24:33', 'Logged out'),
(163, 9, '2016-09-02 09:35:56', 'Logged in'),
(164, 9, '2016-09-02 09:36:28', 'Logged out'),
(165, 3, '2016-09-02 10:13:53', 'Logged in'),
(166, 3, '2016-09-02 10:14:40', 'Logged out'),
(167, 3, '2016-09-02 15:51:38', 'Logged in'),
(168, 3, '2016-09-02 15:51:53', 'Logged in'),
(169, 3, '2016-09-02 15:52:18', 'Logged out'),
(170, 3, '2016-09-02 15:52:42', 'Logged in'),
(171, 3, '2016-09-02 15:53:03', 'Logged out'),
(172, 3, '2016-09-02 15:55:30', 'Logged in'),
(173, 9, '2016-09-02 15:56:55', 'Logged in'),
(174, 3, '2016-09-02 15:57:02', 'Logged out'),
(175, 9, '2016-09-02 16:10:43', 'Logged in'),
(176, 3, '2016-09-02 16:11:23', 'Logged in'),
(177, 9, '2016-09-02 16:12:52', 'Logged out'),
(178, 3, '2016-09-02 16:13:20', 'Logged out'),
(179, 9, '2016-09-02 16:27:11', 'Logged in'),
(180, 3, '2016-09-02 16:27:27', 'Logged in'),
(181, 9, '2016-09-02 17:14:07', 'Logged out'),
(182, 3, '2016-09-02 17:14:14', 'Logged out'),
(183, 3, '2016-09-02 17:16:50', 'Logged in'),
(184, 3, '2016-09-02 17:20:42', 'Logged out'),
(185, 3, '2016-09-02 17:23:59', 'Logged in'),
(186, 9, '2016-09-02 17:24:56', 'Logged in'),
(187, 9, '2016-09-02 17:37:12', 'Logged out'),
(188, 9, '2016-09-02 17:38:24', 'Logged in'),
(189, 9, '2016-09-02 17:40:07', 'Logged out'),
(190, 3, '2016-09-02 17:40:20', 'Logged out'),
(191, 3, '2016-09-02 14:41:21', 'Logged in'),
(192, 9, '2016-09-02 14:41:37', 'Logged in'),
(193, 3, '2016-09-02 15:58:06', 'Logged out'),
(194, 3, '2016-09-02 20:00:25', 'Logged in'),
(195, 3, '2016-09-02 20:30:22', 'Logged out'),
(196, 3, '2016-09-02 20:38:33', 'Logged in'),
(197, 3, '2016-09-02 20:40:54', 'Logged out'),
(198, 3, '2016-09-06 11:04:04', 'Logged in'),
(199, 3, '2016-09-06 11:04:12', 'Logged out'),
(200, 3, '2016-09-06 11:07:04', 'Logged in'),
(201, 3, '2016-09-06 09:29:19', 'Logged out'),
(202, 3, '2016-09-06 09:29:32', 'Logged in'),
(203, 3, '2016-09-06 09:40:24', 'Logged out'),
(204, 3, '2016-09-06 09:45:58', 'Logged in'),
(205, 3, '2016-09-06 09:46:30', 'Logged out'),
(206, 3, '2016-09-06 09:48:45', 'Logged in'),
(207, 3, '2016-09-06 09:51:21', 'Logged in'),
(208, 3, '2016-09-06 10:02:04', 'Logged out'),
(209, 3, '2016-09-06 10:02:12', 'Logged in'),
(210, 3, '2016-09-06 13:04:41', 'Logged out'),
(211, 9, '2016-09-06 13:04:51', 'Logged in'),
(212, 9, '2016-09-06 10:13:30', 'Logged out'),
(213, 3, '2016-09-06 10:13:44', 'Logged in'),
(214, 3, '2016-09-06 10:03:35', 'Logged out'),
(215, 3, '2016-09-06 10:05:57', 'Logged in'),
(216, 3, '2016-09-06 10:06:15', 'Logged out'),
(217, 3, '2016-09-06 10:07:24', 'Logged in'),
(218, 3, '2016-09-06 10:07:35', 'Logged out'),
(219, 3, '2016-09-06 10:09:56', 'Logged in'),
(220, 3, '2016-09-06 14:10:39', 'Logged out'),
(221, 3, '2016-09-06 14:13:53', 'Logged in'),
(222, 3, '2016-09-06 10:08:30', 'Logged out'),
(223, 3, '2016-09-06 10:09:13', 'Logged in'),
(224, 3, '2016-09-06 10:09:22', 'Logged out'),
(225, 3, '2016-09-06 10:10:52', 'Logged in'),
(226, 3, '2016-09-06 10:11:02', 'Logged out'),
(227, 3, '2016-09-06 10:13:59', 'Logged in'),
(228, 3, '2016-09-06 10:14:06', 'Logged out'),
(229, 3, '2016-09-06 10:11:38', 'Logged in'),
(230, 9, '2016-09-06 10:21:05', 'Logged in'),
(231, 9, '2016-09-06 10:24:00', 'Logged out'),
(232, 9, '2016-09-06 10:24:09', 'Logged in'),
(233, 9, '2016-09-06 10:24:13', 'Logged out'),
(234, 3, '2016-09-06 10:24:21', 'Logged in'),
(235, 3, '2016-09-06 10:24:30', 'Logged out'),
(236, 3, '2016-09-06 10:27:49', 'Logged in'),
(237, 3, '2016-09-06 10:30:57', 'Logged in'),
(238, 3, '2016-09-06 10:40:02', 'Logged out'),
(239, 3, '2016-09-06 10:40:40', 'Logged out'),
(240, 3, '2016-09-06 14:35:45', 'Logged in'),
(241, 9, '2016-09-06 14:43:39', 'Logged in'),
(242, 9, '2016-09-06 14:45:12', 'Logged out'),
(243, 3, '2016-09-06 14:46:59', 'Logged out'),
(244, 3, '2016-09-08 13:19:40', 'Logged in'),
(245, 3, '2016-09-08 13:29:09', 'Logged out'),
(246, 9, '2016-09-09 13:24:41', 'Logged in'),
(247, 9, '2016-09-09 13:25:13', 'Logged out'),
(248, 9, '2016-09-09 13:26:11', 'Logged in'),
(249, 9, '2016-09-09 13:26:19', 'Logged out'),
(250, 3, '2016-09-09 13:26:27', 'Logged in'),
(251, 3, '2016-09-09 13:29:42', 'Logged out'),
(252, 3, '2016-09-09 13:59:16', 'Logged in'),
(253, 3, '2016-09-09 13:59:22', 'Logged out'),
(254, 9, '2016-09-09 14:02:50', 'Logged in'),
(255, 9, '2016-09-09 14:03:05', 'Logged out'),
(256, 3, '2016-09-09 14:03:16', 'Logged in'),
(257, 3, '2016-09-09 14:03:23', 'Logged out'),
(258, 9, '2016-09-09 14:03:36', 'Logged in'),
(259, 3, '2016-09-09 14:03:52', 'Logged in'),
(260, 3, '2016-09-09 14:25:48', 'Logged out'),
(261, 3, '2016-09-10 14:26:19', 'Logged in'),
(262, 9, '2016-09-10 14:26:48', 'Logged out'),
(263, 3, '2016-09-10 14:27:17', 'Logged out'),
(264, 3, '2016-09-10 14:28:14', 'Logged in'),
(265, 3, '2016-09-10 14:28:19', 'Logged out'),
(266, 9, '2016-09-10 14:29:07', 'Logged in'),
(267, 3, '2016-09-10 14:29:16', 'Logged in'),
(268, 3, '2016-09-09 14:32:23', 'Logged out'),
(269, 9, '2016-09-09 14:32:55', 'Logged out'),
(270, 3, '2016-09-09 14:33:34', 'Logged in'),
(271, 3, '2016-09-07 14:37:41', 'Logged out'),
(272, 3, '2016-09-07 14:37:53', 'Logged in'),
(273, 3, '2016-09-12 14:39:38', 'Logged out'),
(274, 3, '2016-09-12 14:39:46', 'Logged in'),
(275, 3, '2016-09-12 14:42:55', 'Logged out'),
(276, 3, '2016-09-12 18:43:28', 'Logged in'),
(277, 3, '2016-09-12 18:43:58', 'Logged out'),
(278, 3, '2016-09-12 16:44:26', 'Logged in'),
(279, 9, '2016-09-12 16:48:40', 'Logged in'),
(280, 3, '2016-09-15 17:14:34', 'Logged out'),
(281, 9, '2016-09-10 17:14:53', 'Logged out'),
(282, 3, '2016-09-10 17:14:58', 'Logged in'),
(283, 9, '2016-09-10 17:15:29', 'Logged in'),
(284, 3, '2016-09-10 17:15:39', 'Logged out'),
(285, 3, '2016-09-15 17:16:04', 'Logged in'),
(286, 3, '2016-09-15 17:25:07', 'Logged out'),
(287, 3, '2016-09-15 17:53:37', 'Logged in'),
(288, 3, '2016-09-15 17:54:07', 'Logged out'),
(289, 10, '2016-09-15 17:54:17', 'Logged in'),
(290, 10, '2016-09-15 18:03:49', 'Logged out'),
(291, 10, '2016-09-15 18:05:26', 'Logged in'),
(292, 10, '2016-09-15 18:07:02', 'Logged out'),
(293, 10, '2016-09-09 18:07:25', 'Logged in'),
(294, 10, '2016-09-09 16:09:43', 'Logged out'),
(295, 10, '2016-09-09 16:09:49', 'Logged in'),
(296, 10, '2016-09-09 16:12:59', 'Logged out'),
(297, 10, '2016-09-09 18:05:39', 'Logged in'),
(298, 10, '2016-09-09 18:05:45', 'Logged out'),
(299, 10, '2016-09-29 12:23:03', 'Logged in'),
(300, 10, '2016-09-29 12:25:05', 'Logged out'),
(301, 10, '2016-09-29 15:13:49', 'Logged in'),
(302, 10, '2016-09-29 15:15:16', 'Logged out'),
(303, 10, '2016-10-10 13:11:06', 'Logged in'),
(304, 10, '2016-10-10 13:14:33', 'Logged in'),
(305, 10, '2016-10-10 13:29:44', 'Logged in'),
(306, 10, '2016-10-10 13:43:37', 'Logged out'),
(307, 3, '2016-10-10 13:44:20', 'Logged in'),
(308, 3, '2016-10-10 13:45:45', 'Logged out'),
(309, 3, '2016-10-10 13:46:05', 'Logged in'),
(310, 3, '2016-10-10 14:00:48', 'Logged out'),
(311, 3, '2016-10-10 14:00:58', 'Logged in'),
(312, 3, '2016-10-10 14:02:17', 'Logged out'),
(313, 10, '2016-10-10 15:29:32', 'Logged in'),
(314, 3, '2016-10-10 15:31:56', 'Logged in'),
(315, 10, '2016-10-10 15:39:15', 'Logged out'),
(316, 3, '2016-10-10 15:41:21', 'Logged out'),
(317, 10, '2016-10-10 15:43:36', 'Logged in'),
(318, 3, '2016-10-10 15:46:09', 'Logged in'),
(319, 10, '2016-10-10 15:50:28', 'Logged out'),
(320, 3, '2016-10-10 15:51:13', 'Logged out'),
(321, 10, '2016-11-07 06:52:09', 'Logged in'),
(322, 10, '2016-11-07 06:53:32', 'Logged in'),
(323, 10, '2016-11-07 06:54:35', 'Logged out'),
(324, 10, '2016-11-07 06:56:53', 'Logged out'),
(325, 10, '2016-11-08 08:35:49', 'Logged in'),
(326, 10, '2016-11-08 08:36:02', 'Logged out'),
(327, 10, '2016-11-08 08:36:17', 'Logged in'),
(328, 9, '2016-11-08 08:38:42', 'Logged in'),
(329, 10, '2016-11-08 08:49:36', 'Logged out'),
(330, 10, '2016-11-08 08:49:54', 'Logged in'),
(331, 10, '2016-11-08 08:58:21', 'Logged out'),
(332, 9, '2016-11-08 08:58:26', 'Logged out'),
(333, 10, '2016-11-25 08:59:08', 'Logged in'),
(334, 9, '2016-11-25 08:59:40', 'Logged in'),
(335, 9, '2016-11-25 09:04:20', 'Logged out'),
(336, 10, '2016-11-25 09:07:13', 'Logged out'),
(337, 10, '2016-11-25 14:36:52', 'Logged in'),
(338, 10, '2016-11-25 14:51:40', 'Logged out'),
(339, 9, '2016-11-25 14:52:08', 'Logged in'),
(340, 9, '2016-11-08 15:05:54', 'Logged out'),
(341, 10, '2016-11-08 15:06:11', 'Logged in'),
(342, 10, '2016-11-08 15:10:05', 'Logged out'),
(343, 10, '2016-11-25 15:10:41', 'Logged in'),
(344, 10, '2016-11-25 15:16:49', 'Logged out'),
(345, 10, '2016-11-08 15:19:19', 'Logged in'),
(346, 10, '2016-11-08 15:21:44', 'Logged out'),
(347, 10, '2016-11-16 15:22:12', 'Logged in'),
(348, 10, '2016-11-16 15:32:09', 'Logged out'),
(349, 3, '2016-11-17 13:56:35', 'Logged in'),
(350, 3, '2016-11-17 14:01:21', 'Logged in'),
(351, 3, '2016-11-22 14:10:38', 'Logged in'),
(352, 3, '2016-11-25 14:24:33', 'Logged in'),
(353, 3, '2016-11-25 14:25:57', 'Logged in'),
(354, 3, '2016-11-26 14:23:38', 'Logged out'),
(355, 3, '2016-11-26 14:24:44', 'Logged in'),
(356, 3, '2016-11-26 14:25:23', 'Logged out'),
(357, 10, '2016-11-29 09:29:19', 'Logged in'),
(358, 10, '2016-11-29 09:41:32', 'Logged out'),
(359, 10, '2016-12-02 11:48:44', 'Logged in'),
(360, 10, '2016-12-02 11:51:56', 'Logged out'),
(361, 3, '2016-12-07 13:11:07', 'Logged in'),
(362, 3, '2016-12-07 13:11:50', 'Logged out'),
(363, 3, '2016-12-07 13:16:26', 'Logged in'),
(364, 3, '2016-12-07 13:16:45', 'Logged out'),
(365, 3, '2016-12-07 13:19:18', 'Logged in'),
(366, 3, '2016-12-07 13:21:20', 'Logged out'),
(367, 10, '2016-12-07 13:22:11', 'Logged in'),
(368, 10, '2016-12-07 13:22:44', 'Logged out'),
(369, 10, '2016-12-10 14:18:57', 'Logged in'),
(370, 10, '2016-12-10 14:42:26', 'Logged out'),
(371, 10, '2016-12-16 08:35:20', 'Logged in'),
(372, 10, '2016-12-16 08:44:55', 'Logged in'),
(373, 10, '2016-12-16 08:46:08', 'Logged in'),
(374, 10, '2016-12-16 08:46:49', 'Logged in'),
(375, 10, '2016-11-29 08:48:04', 'Logged in'),
(376, 10, '2016-11-29 08:48:48', 'Logged in'),
(377, 10, '2016-11-29 12:07:40', 'Logged in'),
(378, 10, '2016-11-29 12:14:48', 'Logged out'),
(379, 3, '2016-11-29 13:07:59', 'Logged in'),
(380, 3, '2016-11-29 14:11:28', 'Logged in'),
(381, 3, '2016-11-29 14:18:12', 'Logged in'),
(382, 3, '2016-11-29 14:19:07', 'Logged in'),
(383, 3, '2018-01-08 00:47:19', 'Logged in'),
(384, 3, '2018-01-08 00:47:55', 'Logged out'),
(385, 10, '2018-01-08 00:47:59', 'Logged in'),
(386, 10, '2018-01-08 00:49:17', 'Logged out'),
(387, 3, '2018-01-08 00:56:40', 'Logged in'),
(388, 3, '2018-01-08 00:56:49', 'Logged out'),
(389, 3, '2018-01-08 01:12:50', 'Logged in'),
(390, 3, '2018-01-08 01:13:47', 'Logged out'),
(391, 3, '2018-01-08 01:18:09', 'Logged in'),
(392, 3, '2018-01-08 01:19:08', 'Logged out'),
(393, 3, '2018-01-18 14:53:05', 'Logged in'),
(394, 3, '2018-01-18 14:56:34', 'Logged out'),
(395, 3, '2018-01-22 08:56:09', 'Logged in'),
(396, 3, '2018-01-22 08:58:30', 'Logged out'),
(397, 3, '2018-01-22 09:01:05', 'Logged in'),
(398, 3, '2018-01-22 09:06:32', 'Logged out'),
(399, 3, '2018-01-22 09:08:32', 'Logged in'),
(400, 3, '2018-01-22 09:08:51', 'Logged out'),
(401, 3, '2018-01-22 09:11:16', 'Logged in'),
(402, 3, '2018-01-22 09:11:22', 'Logged out'),
(403, 3, '2018-01-22 09:13:02', 'Logged in'),
(404, 3, '2018-01-22 12:24:10', 'Logged out'),
(405, 3, '2018-01-22 12:33:19', 'Logged in'),
(406, 3, '2018-01-22 12:34:17', 'Logged out'),
(407, 3, '2018-01-22 12:37:17', 'Logged in'),
(408, 3, '2018-01-22 12:38:16', 'Logged out'),
(409, 3, '2018-01-22 12:43:24', 'Logged in'),
(410, 3, '2018-01-22 12:43:54', 'Logged out'),
(411, 3, '2018-02-10 02:11:24', 'Logged in'),
(412, 3, '2018-02-10 02:11:47', 'Logged out'),
(413, 3, '2018-02-10 02:17:35', 'Logged in'),
(414, 3, '2018-02-10 02:17:58', 'Logged out'),
(415, 3, '2018-02-09 01:02:55', 'Logged in'),
(416, 3, '2018-02-09 03:28:49', 'Logged in'),
(417, 3, '2018-02-09 03:49:52', 'Logged out'),
(418, 3, '2018-02-09 03:54:21', 'Logged in'),
(419, 3, '2018-02-09 03:54:41', 'Logged out'),
(420, 3, '2018-02-09 03:55:19', 'Logged in'),
(421, 3, '2018-02-09 03:55:51', 'Logged out'),
(422, 3, '2018-02-09 04:03:36', 'Logged in'),
(423, 3, '2018-02-09 04:11:19', 'Logged out'),
(424, 3, '2018-02-09 04:14:07', 'Logged in'),
(425, 3, '2018-02-09 04:14:11', 'Logged out'),
(426, 3, '2018-03-03 07:05:32', 'Logged in'),
(427, 3, '2018-03-03 17:35:29', 'Logged out'),
(428, 3, '2018-03-12 01:13:46', 'Logged in'),
(429, 3, '2018-03-12 01:27:30', 'Logged out'),
(430, 3, '2018-03-25 15:18:12', 'Logged in'),
(431, 3, '2018-03-25 15:21:08', 'Logged out'),
(432, 3, '2018-03-25 15:30:29', 'Logged in'),
(433, 3, '2018-03-25 15:31:00', 'Logged out'),
(434, 3, '2018-03-25 15:58:25', 'Logged in'),
(435, 3, '2018-03-25 16:00:33', 'Logged out'),
(436, 3, '2018-03-25 19:01:34', 'Logged in'),
(437, 3, '2018-03-25 19:02:33', 'Logged out'),
(438, 3, '2018-03-26 19:05:17', 'Logged in'),
(439, 3, '2018-03-26 19:07:29', 'Logged out'),
(440, 3, '2018-03-26 19:48:22', 'Logged in'),
(441, 3, '2018-03-26 19:49:39', 'Logged out'),
(442, 3, '2018-03-27 00:52:06', 'Logged in'),
(443, 3, '2018-03-27 00:52:17', 'Logged out'),
(444, 3, '2018-03-27 01:02:20', 'Logged in'),
(445, 3, '2018-03-27 01:05:02', 'Logged out'),
(446, 3, '2018-03-27 01:07:21', 'Logged in'),
(447, 3, '2018-03-27 01:07:24', 'Logged out'),
(448, 3, '2018-03-27 01:07:37', 'Logged in'),
(449, 3, '2018-03-27 01:08:24', 'Logged out'),
(450, 3, '2018-03-27 01:44:54', 'Logged in'),
(451, 3, '2018-03-27 01:50:51', 'Logged in'),
(452, 3, '2018-03-27 01:52:13', 'Logged out'),
(453, 3, '2018-03-27 01:53:50', 'Logged in'),
(454, 3, '2018-03-27 01:54:33', 'Logged out'),
(455, 3, '2018-03-27 01:57:04', 'Logged in'),
(456, 3, '2018-03-27 01:57:28', 'Logged out'),
(457, 3, '2018-08-06 11:27:17', 'Logged in'),
(458, 3, '2018-08-06 11:30:20', 'Logged out'),
(459, 3, '2018-08-06 12:05:29', 'Logged in'),
(460, 3, '2018-08-06 12:06:17', 'Logged out'),
(461, 3, '2018-08-07 10:46:29', 'Logged in'),
(462, 3, '2018-08-07 10:46:57', 'Logged out'),
(463, 3, '2018-08-07 10:51:18', 'Logged in'),
(464, 3, '2018-08-07 10:51:36', 'Logged out'),
(465, 3, '2018-08-07 10:53:23', 'Logged in'),
(466, 3, '2018-08-07 10:54:00', 'Logged out'),
(467, 3, '2018-08-11 06:54:34', 'Logged in'),
(468, 3, '2018-08-11 06:54:49', 'Logged out'),
(469, 3, '2018-08-11 07:07:29', 'Logged in'),
(470, 3, '2018-08-11 07:08:38', 'Logged out'),
(471, 3, '2018-08-11 07:13:23', 'Logged in'),
(472, 3, '2018-08-11 07:15:28', 'Logged out'),
(473, 3, '2018-08-11 08:20:20', 'Logged in'),
(474, 3, '2018-08-11 08:23:37', 'Logged out'),
(475, 3, '2018-08-11 08:37:44', 'Logged in'),
(476, 3, '2018-08-11 08:38:27', 'Logged out'),
(477, 3, '2018-08-11 08:43:38', 'Logged in'),
(478, 3, '2018-08-11 08:44:00', 'Logged out'),
(479, 3, '2018-08-11 08:45:00', 'Logged in'),
(480, 3, '2018-08-11 08:46:02', 'Logged out'),
(481, 3, '2018-08-11 08:52:56', 'Logged in'),
(482, 3, '2018-08-11 08:54:31', 'Logged out');

-- --------------------------------------------------------

--
-- Table structure for table `tblpayment`
--

CREATE TABLE `tblpayment` (
  `PaymentId` int(11) NOT NULL,
  `BorrowId` int(11) NOT NULL,
  `Payment` double NOT NULL,
  `Change` double NOT NULL,
  `DatePayed` date NOT NULL,
  `BorrowerId` int(11) NOT NULL,
  `Remarks` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpayment`
--

INSERT INTO `tblpayment` (`PaymentId`, `BorrowId`, `Payment`, `Change`, `DatePayed`, `BorrowerId`, `Remarks`) VALUES
(1, 12345673, 130, 0, '2016-11-22', 912, 'Settled'),
(2, 12345673, 4, 0, '2016-11-22', 912, 'Settled'),
(3, 12345671, 4, 0, '2016-11-22', 912, 'Settled'),
(4, 18293746, 37, 13, '2018-02-09', 912, 'Settled'),
(5, 1345672, 37, 3, '2018-02-09', 912, 'Settled'),
(6, 1345673, 1200, 100, '2018-03-26', 1234, 'Settled');

-- --------------------------------------------------------

--
-- Table structure for table `tbltransaction`
--

CREATE TABLE `tbltransaction` (
  `TransactionID` int(11) NOT NULL,
  `IBSN` varchar(13) NOT NULL,
  `NoCopies` int(11) NOT NULL,
  `DateBorrowed` datetime NOT NULL,
  `Purpose` varchar(90) NOT NULL,
  `Status` varchar(30) NOT NULL,
  `DueDate` datetime NOT NULL,
  `BorrowerId` int(11) NOT NULL,
  `Borrowed` tinyint(1) NOT NULL,
  `Due` tinyint(1) NOT NULL,
  `Returned` tinyint(1) NOT NULL,
  `DateReturned` datetime NOT NULL,
  `Remarks` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltransaction`
--

INSERT INTO `tbltransaction` (`TransactionID`, `IBSN`, `NoCopies`, `DateBorrowed`, `Purpose`, `Status`, `DueDate`, `BorrowerId`, `Borrowed`, `Due`, `Returned`, `DateReturned`, `Remarks`) VALUES
(1, '15263712', 1, '2016-10-10 13:32:12', 'Borrowed for 3days', 'Returned', '2016-10-13 13:32:12', 4321, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(2, '12345671', 1, '2016-10-10 13:32:38', 'Borrowed for 3days', 'Returned', '2016-10-13 13:32:38', 912, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(3, '18293746', 1, '2016-10-10 13:37:13', 'Overnight', 'Returned', '2016-10-11 13:37:13', 921, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(4, '11726354', 1, '2016-10-10 13:37:36', 'Photocopy', 'Returned', '2016-10-10 14:07:36', 9213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(5, '12345678', 1, '2016-10-10 13:50:29', 'Borrowed for 3days', 'Returned', '2016-10-13 13:50:29', 9213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(6, '12345673', 1, '2016-10-10 13:50:47', 'Overnight', 'Returned', '2016-10-11 13:50:47', 9213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(7, '1345672', 1, '2016-10-10 13:51:07', 'Borrowed for 3days', 'Returned', '2016-10-13 13:51:07', 4321, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(8, '15243678', 1, '2016-10-10 13:51:27', 'Borrowed for 3days', 'Returned', '2016-10-13 13:51:27', 4321, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(9, '18293746', 1, '2016-10-10 13:55:23', 'Photocopy', 'Returned', '2016-10-10 14:25:23', 9213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(10, '11726354', 1, '2016-10-10 13:55:51', 'Photocopy', 'Returned', '2016-10-10 14:25:51', 9213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(11, '10928273', 1, '2016-10-10 13:57:44', 'Research', 'Returned', '2016-10-10 17:30:00', 9213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(12, '12345678', 1, '2016-10-10 15:34:20', 'Borrowed for 3days', 'Returned', '2016-10-19 15:33:31', 912, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(13, '98172634', 1, '2016-10-10 15:34:41', 'Borrowed for 3days', 'Returned', '2016-10-19 15:33:53', 912, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(14, '9812345', 1, '2016-11-08 08:42:09', 'Borrowed for 3days', 'Returned', '2016-11-17 08:40:38', 912, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(15, '12345673', 1, '2016-11-08 08:46:40', 'Overnight', 'Returned', '2016-11-15 08:45:08', 912, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(16, '12345673', 1, '2016-11-08 08:53:53', 'Overnight', 'Returned', '2016-11-09 08:52:21', 912, 0, 0, 0, '0000-00-00 00:00:00', 'Overdue'),
(17, '19872634', 1, '2016-11-08 15:09:46', 'Borrowed for 3days', 'Returned', '2016-11-11 15:09:46', 213, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(18, '12345673', 1, '2016-11-17 13:58:29', 'Overnight', 'Returned', '2016-11-18 13:58:29', 912, 0, 0, 0, '0000-00-00 00:00:00', 'Overdue'),
(19, '12345671', 1, '2016-11-17 13:58:59', 'Borrowed for 3days', 'Returned', '2016-11-20 13:58:59', 912, 0, 0, 0, '0000-00-00 00:00:00', 'Overdue'),
(20, '1345672', 1, '2016-11-22 14:16:03', 'Borrowed for 3days', 'Returned', '2016-11-25 14:16:03', 912, 0, 0, 0, '0000-00-00 00:00:00', 'Overdue'),
(21, '18293746', 1, '2016-11-22 14:16:24', 'Research', 'Returned', '2016-11-22 17:30:00', 912, 0, 0, 0, '0000-00-00 00:00:00', 'Overdue'),
(22, '12345678', 1, '2016-11-29 14:19:24', 'Borrowed for 3days', 'Returned', '2016-12-02 14:19:24', 1234, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(23, '12345673', 1, '2018-02-09 04:03:56', 'Photocopy', 'Returned', '2018-02-09 04:33:56', 123432, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(24, '12345673', 1, '2018-03-03 07:13:36', 'Research', 'Returned', '2018-03-03 11:30:00', 921, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(25, '1345673', 1, '2018-03-23 19:01:51', 'Overnight', 'Returned', '2018-03-24 19:01:51', 1234, 0, 0, 0, '0000-00-00 00:00:00', 'Overdue'),
(26, '1345673', 1, '2018-03-27 01:51:19', 'Research', 'Returned', '2018-03-27 11:30:00', 123432, 0, 0, 0, '0000-00-00 00:00:00', 'On Time'),
(27, '1345672', 1, '2020-04-09 05:38:53', 'Research', 'Borrowed', '2020-04-09 11:30:00', 1234, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, '12345672', 1, '2020-05-03 07:52:00', '1 week', 'Returned', '2020-05-03 07:52:00', 213, 0, 0, 1, '2020-05-03 00:00:00', 'Ontime'),
(29, '12345678', 1, '2020-05-03 08:09:00', '1 week', 'Cancelled', '2020-05-03 08:09:00', 213, 0, 0, 0, '2020-05-03 00:00:00', 'Cancelled'),
(30, '12345677', 1, '2020-05-03 08:09:00', '1 week', 'Cancelled', '2020-05-03 08:09:00', 1234, 0, 0, 0, '2020-05-03 00:00:00', 'Cancelled'),
(31, '1345673', 1, '2020-05-03 08:38:00', '1 week', 'Returned', '2020-05-03 08:38:00', 4321, 0, 0, 1, '2020-05-03 00:00:00', 'Ontime'),
(32, '12345671', 1, '2020-05-03 08:41:00', '1 week', 'Returned', '2020-05-10 08:41:00', 123432, 0, 0, 1, '2020-05-03 00:00:00', 'Ontime'),
(35, '12345678', 1, '2020-05-03 10:34:00', '1 week', 'Returned', '2020-05-10 10:34:00', 213, 0, 0, 1, '2020-05-03 10:34:00', 'Ontime'),
(36, '12345678', 1, '2020-05-03 11:07:00', '1 week', 'Returned', '2020-05-10 11:07:00', 213, 0, 1, 1, '2022-05-24 04:51:00', 'Over Due'),
(37, '12345671', 1, '2020-05-03 01:17:00', '1 week', 'Confirmed', '2020-05-10 01:17:00', 213, 1, 0, 0, '2020-05-10 00:00:00', 'Borrowed for on Week'),
(38, '1345673', 1, '2020-05-03 01:18:00', '1 week', 'Confirmed', '2020-05-10 01:18:00', 4321, 1, 0, 0, '2020-05-10 00:00:00', 'Borrowed for on Week'),
(39, '12345670', 1, '2020-05-04 01:31:00', '1 week', 'Cancelled', '2020-05-11 01:31:00', 20200003, 0, 0, 0, '2020-05-11 00:00:00', 'Cancelled'),
(42, '12345672', 1, '2020-05-04 00:00:00', '1 week', 'Confirmed', '2020-05-11 01:37:00', 20200003, 1, 0, 0, '2020-05-11 00:00:00', 'Borrowed for on Week'),
(43, '12345673', 1, '2020-05-04 00:00:00', '1 week', 'Confirmed', '2020-05-11 01:38:00', 20200003, 1, 0, 0, '2020-05-11 00:00:00', 'Borrowed for on Week'),
(44, '14256372', 1, '2022-06-04 00:00:00', '1 week', 'Returned', '2020-05-11 04:28:00', 202000015, 0, 1, 1, '2022-06-04 08:15:00', 'Over Due'),
(45, '11726354', 1, '2022-06-04 00:00:00', '1 week', 'Returned', '2020-05-11 04:29:00', 202000016, 0, 1, 1, '2022-06-04 08:15:00', 'Over Due'),
(46, '15243678', 1, '2022-05-15 10:01:00', '1 week', 'Pending', '2022-05-22 10:01:00', 202200017, 1, 0, 0, '2022-05-22 00:00:00', 'Borrowed for on Week'),
(47, '15243678', 1, '2022-05-15 10:13:00', '1 week', 'Pending', '2022-05-22 10:13:00', 202200018, 1, 0, 0, '2022-05-22 00:00:00', 'Borrowed for on Week'),
(48, '11726354', 1, '2022-05-15 11:12:00', '1 week', 'Pending', '2022-05-22 11:12:00', 202200018, 1, 0, 0, '2022-05-22 00:00:00', 'Borrowed for on Week');

-- --------------------------------------------------------

--
-- Table structure for table `tbltransaction2`
--

CREATE TABLE `tbltransaction2` (
  `TransID` int(11) NOT NULL,
  `stuNo` int(100) NOT NULL,
  `bNo` int(100) NOT NULL,
  `dueDate` date NOT NULL,
  `borrowDate` date NOT NULL,
  `returnDate` date DEFAULT NULL,
  `fine` int(100) DEFAULT NULL,
  `rating` int(1) DEFAULT NULL,
  `copies` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbltransaction2`
--

INSERT INTO `tbltransaction2` (`TransID`, `stuNo`, `bNo`, `dueDate`, `borrowDate`, `returnDate`, `fine`, `rating`, `copies`) VALUES
(1, 10, 6, '2022-05-02', '2022-05-01', '2022-06-06', 350, 5, 1),
(16, 10, 1, '2022-07-08', '2022-06-08', '2022-06-08', 0, 5, 1),
(17, 10, 1, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(18, 10, 2, '2022-07-08', '2022-06-08', '2022-06-08', 0, 4, 1),
(19, 10, 9, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(21, 10, 6, '2022-07-08', '2022-06-08', '2022-06-08', 0, 3, 1),
(22, 10, 3, '2022-07-08', '2022-06-08', NULL, NULL, NULL, 1),
(23, 10, 7, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(24, 10, 13, '2022-07-08', '2022-06-08', '2022-06-08', 0, 4, 1),
(25, 10, 11, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(26, 10, 11, '2022-07-08', '2022-06-08', '2022-06-09', 0, NULL, 1),
(27, 10, 12, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(29, 10, 1, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(31, 10, 8, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(32, 5, 10, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(34, 10, 10, '2022-07-08', '2022-06-08', '2022-06-08', 0, NULL, 1),
(35, 5, 8, '2022-07-08', '2022-06-08', '2022-06-09', 0, NULL, 1),
(36, 10, 2, '2022-07-09', '2022-06-09', NULL, NULL, NULL, 1),
(37, 10, 13, '2022-07-09', '2022-06-09', '2022-06-09', 0, NULL, 1),
(38, 10, 1, '2022-07-09', '2022-06-09', '2022-06-09', 0, NULL, 1),
(39, 10, 12, '2022-07-09', '2022-06-09', '2022-06-09', 0, NULL, 1),
(40, 10, 6, '2022-07-09', '2022-06-09', '2022-06-09', 0, NULL, 1),
(41, 10, 9, '2022-07-09', '2022-06-09', '2022-06-09', 0, NULL, 1),
(42, 10, 17, '2022-07-09', '2022-06-09', '2022-06-09', 0, NULL, 1),
(44, 12, 9, '2022-07-09', '2022-06-09', NULL, NULL, NULL, 1),
(45, 15, 15, '2022-07-09', '2022-06-09', NULL, NULL, NULL, 1),
(46, 10, 13, '2022-07-09', '2022-06-09', NULL, NULL, 1, 1),
(47, 16, 11, '2022-07-09', '2022-06-09', '2022-06-09', 0, 5, 1),
(48, 16, 12, '2022-07-09', '2022-06-09', NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `stuNo` int(100) NOT NULL,
  `stuID` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuName` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuBirth` date NOT NULL,
  `stuMail` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuPhone` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuPwd` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuRole` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuStatus` varchar(11) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuPic` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stuVerifC` int(6) NOT NULL,
  `isVerified` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`stuNo`, `stuID`, `stuName`, `stuBirth`, `stuMail`, `stuPhone`, `stuPwd`, `stuRole`, `stuStatus`, `stuPic`, `stuVerifC`, `isVerified`) VALUES
(5, 'admin', '', '1988-08-08', '', '', 'admin', 'Administrator', '', '', 585785, 0),
(10, 'A1093340', 'Velen', '2021-12-15', 'velenyuniar@gmail.com', '0928382947', 'velenynr', 'Student', '', '', 248677, 1),
(12, 'A1101111', 'Bernard', '2005-08-31', 'velenynr@gmail.com', '0823782944', 'bernardhere', 'Student', '', '', 194472, 0),
(13, 'A1093300', 'Sunny', '2021-12-06', 'velenyuniar@gmail.com', '0823782944', 'sunnyhere', 'Student', '', '', 861306, 1),
(14, 'A1093333', 'Francheska Richardson', '1997-06-22', 'a1093333@mail.nuk.edu.tw', '0984253176', 'Ilovecats', 'Student', '', '', 963918, 1),
(15, 'A1101100', 'Moon', '2021-12-07', 'a1093340@mail.nuk.edu.tw', '0928382947', 'moonhere', 'Student', '', '', 229481, 1),
(16, 'A1093388', 'Rebecca', '2021-12-14', 'a1093340@mail.nuk.edu.tw', '0928382947', 'rebhere', 'Student', '', '', 329119, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  ADD PRIMARY KEY (`AUTOID`);

--
-- Indexes for table `tblbooknumber`
--
ALTER TABLE `tblbooknumber`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblbooks`
--
ALTER TABLE `tblbooks`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `tblborrower`
--
ALTER TABLE `tblborrower`
  ADD PRIMARY KEY (`IDNO`),
  ADD UNIQUE KEY `BorrowerId` (`BorrowerId`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CategoryId`);

--
-- Indexes for table `tbllogs`
--
ALTER TABLE `tbllogs`
  ADD PRIMARY KEY (`LogId`);

--
-- Indexes for table `tblpayment`
--
ALTER TABLE `tblpayment`
  ADD PRIMARY KEY (`PaymentId`);

--
-- Indexes for table `tbltransaction`
--
ALTER TABLE `tbltransaction`
  ADD PRIMARY KEY (`TransactionID`);

--
-- Indexes for table `tbltransaction2`
--
ALTER TABLE `tbltransaction2`
  ADD PRIMARY KEY (`TransID`),
  ADD KEY `BorrowNo` (`bNo`),
  ADD KEY `Test` (`stuNo`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`stuNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  MODIFY `AUTOID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbooknumber`
--
ALTER TABLE `tblbooknumber`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblbooks`
--
ALTER TABLE `tblbooks`
  MODIFY `BookID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tblborrower`
--
ALTER TABLE `tblborrower`
  MODIFY `IDNO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbllogs`
--
ALTER TABLE `tbllogs`
  MODIFY `LogId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=483;

--
-- AUTO_INCREMENT for table `tblpayment`
--
ALTER TABLE `tblpayment`
  MODIFY `PaymentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbltransaction`
--
ALTER TABLE `tbltransaction`
  MODIFY `TransactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tbltransaction2`
--
ALTER TABLE `tbltransaction2`
  MODIFY `TransID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `stuNo` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbltransaction2`
--
ALTER TABLE `tbltransaction2`
  ADD CONSTRAINT `BorrowNo` FOREIGN KEY (`bNo`) REFERENCES `tblbooks` (`BookID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Test` FOREIGN KEY (`stuNo`) REFERENCES `tblusers` (`stuNo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
